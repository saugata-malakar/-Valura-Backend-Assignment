// Analytics engine - VWAP and trade aggregates
export interface TradeAggregate {
  symbol: string
  timestamp: number
  open: number
  high: number
  low: number
  close: number
  volume: number
  vwap: number
}

class AnalyticsEngine {
  private tradeData: Map<string, Array<{ price: number; quantity: number; timestamp: number }>> = new Map()
  private aggregates: Map<string, TradeAggregate[]> = new Map()

  recordTrade(symbol: string, price: number, quantity: number, timestamp: number): void {
    if (!this.tradeData.has(symbol)) {
      this.tradeData.set(symbol, [])
    }
    this.tradeData.get(symbol)!.push({ price, quantity, timestamp })
  }

  calculateVWAP(symbol: string, startTime: number, endTime: number): number {
    const trades = this.tradeData.get(symbol) || []
    const relevantTrades = trades.filter((t) => t.timestamp >= startTime && t.timestamp <= endTime)

    if (relevantTrades.length === 0) return 0

    const totalValue = relevantTrades.reduce((sum, t) => sum + t.price * t.quantity, 0)
    const totalQuantity = relevantTrades.reduce((sum, t) => sum + t.quantity, 0)

    return totalValue / totalQuantity
  }

  aggregate1Min(symbol: string): TradeAggregate[] {
    const trades = this.tradeData.get(symbol) || []
    const aggregateMap = new Map<number, { prices: number[]; quantities: number[] }>()

    trades.forEach((t) => {
      const bucketTime = Math.floor(t.timestamp / 60000) * 60000
      if (!aggregateMap.has(bucketTime)) {
        aggregateMap.set(bucketTime, { prices: [], quantities: [] })
      }
      aggregateMap.get(bucketTime)!.prices.push(t.price)
      aggregateMap.get(bucketTime)!.quantities.push(t.quantity)
    })

    const result: TradeAggregate[] = []
    aggregateMap.forEach((data, bucketTime) => {
      const vwap = this.calculateVWAP(symbol, bucketTime, bucketTime + 60000)
      result.push({
        symbol,
        timestamp: bucketTime,
        open: data.prices[0],
        high: Math.max(...data.prices),
        low: Math.min(...data.prices),
        close: data.prices[data.prices.length - 1],
        volume: data.quantities.reduce((a, b) => a + b, 0),
        vwap,
      })
    })

    return result
  }

  aggregate5Min(symbol: string): TradeAggregate[] {
    const oneMinAggregates = this.aggregate1Min(symbol)
    const aggregateMap = new Map<number, TradeAggregate[]>()

    oneMinAggregates.forEach((agg) => {
      const bucketTime = Math.floor(agg.timestamp / 300000) * 300000
      if (!aggregateMap.has(bucketTime)) {
        aggregateMap.set(bucketTime, [])
      }
      aggregateMap.get(bucketTime)!.push(agg)
    })

    const result: TradeAggregate[] = []
    aggregateMap.forEach((aggs, bucketTime) => {
      const prices = aggs.map((a) => a.open).concat(aggs.map((a) => a.close))
      result.push({
        symbol,
        timestamp: bucketTime,
        open: aggs[0].open,
        high: Math.max(...aggs.map((a) => a.high)),
        low: Math.min(...aggs.map((a) => a.low)),
        close: aggs[aggs.length - 1].close,
        volume: aggs.reduce((sum, a) => sum + a.volume, 0),
        vwap: aggs.reduce((sum, a) => sum + a.vwap, 0) / aggs.length,
      })
    })

    return result
  }

  getVWAP(symbol: string, startTime: number, endTime: number): number {
    return this.calculateVWAP(symbol, startTime, endTime)
  }
}

export const analyticsEngine = new AnalyticsEngine()
