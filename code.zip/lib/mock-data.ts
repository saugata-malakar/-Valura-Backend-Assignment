export function generateMockOrderBook() {
  return {
    bids: Array.from({ length: 15 }, (_, i) => [
      (50000 - i * 5 + (Math.random() - 0.5) * 10).toFixed(2),
      (Math.random() * 50 + 10).toFixed(4),
    ]),
    asks: Array.from({ length: 15 }, (_, i) => [
      (50005 + i * 5 + (Math.random() - 0.5) * 10).toFixed(2),
      (Math.random() * 50 + 10).toFixed(4),
    ]),
  }
}

export function generateMockTrade() {
  return {
    id: Math.random().toString(36).substr(2, 9),
    symbol: "BTC/USD",
    side: Math.random() > 0.5 ? "buy" : "sell",
    price: (50000 + (Math.random() - 0.5) * 500).toFixed(2),
    quantity: (Math.random() * 2 + 0.1).toFixed(4),
    timestamp: Date.now(),
  }
}
