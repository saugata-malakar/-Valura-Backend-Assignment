// Event-sourcing foundation - persist all events and derive state by replay
export interface DomainEvent {
  id: string
  type: string
  aggregateId: string
  timestamp: number
  data: any
  version: number
}

export interface EventStore {
  append(event: DomainEvent): Promise<void>
  getEvents(aggregateId: string, fromVersion?: number): Promise<DomainEvent[]>
  getAllEvents(fromTimestamp?: number): Promise<DomainEvent[]>
  subscribe(callback: (event: DomainEvent) => void): () => void
}

class InMemoryEventStore implements EventStore {
  private events: DomainEvent[] = []
  private subscribers: Set<(event: DomainEvent) => void> = new Set()
  private eventsByAggregate: Map<string, DomainEvent[]> = new Map()

  async append(event: DomainEvent): Promise<void> {
    this.events.push(event)

    if (!this.eventsByAggregate.has(event.aggregateId)) {
      this.eventsByAggregate.set(event.aggregateId, [])
    }
    this.eventsByAggregate.get(event.aggregateId)!.push(event)

    this.subscribers.forEach((cb) => cb(event))
  }

  async getEvents(aggregateId: string, fromVersion = 0): Promise<DomainEvent[]> {
    return (this.eventsByAggregate.get(aggregateId) || []).filter((e) => e.version >= fromVersion)
  }

  async getAllEvents(fromTimestamp = 0): Promise<DomainEvent[]> {
    return this.events.filter((e) => e.timestamp >= fromTimestamp)
  }

  subscribe(callback: (event: DomainEvent) => void): () => void {
    this.subscribers.add(callback)
    return () => this.subscribers.delete(callback)
  }
}

export const eventStore = new InMemoryEventStore()

// Event factory helpers
export const createEvent = (type: string, aggregateId: string, data: any, version = 1): DomainEvent => ({
  id: `${aggregateId}-${type}-${Date.now()}`,
  type,
  aggregateId,
  timestamp: Date.now(),
  data,
  version,
})

export const EventTypes = {
  ORDER_PLACED: "OrderPlaced",
  ORDER_FILLED: "OrderFilled",
  ORDER_CANCELLED: "OrderCancelled",
  TRADE_EXECUTED: "TradeExecuted",
  INSTRUMENT_REGISTERED: "InstrumentRegistered",
}
