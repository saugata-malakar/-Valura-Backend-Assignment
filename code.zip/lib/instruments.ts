// Multi-instrument support
export interface Instrument {
  symbol: string
  baseCurrency: string
  quoteCurrency: string
  minOrderSize: number
  maxOrderSize: number
  priceTickSize: number
  workerId: string // Partition assignment
}

export interface InstrumentRegistry {
  register(instrument: Instrument): Promise<void>
  get(symbol: string): Instrument | undefined
  getAll(): Instrument[]
  getByWorkerId(workerId: string): Instrument[]
}

class LocalInstrumentRegistry implements InstrumentRegistry {
  private instruments: Map<string, Instrument> = new Map()

  async register(instrument: Instrument): Promise<void> {
    this.instruments.set(instrument.symbol, instrument)
  }

  get(symbol: string): Instrument | undefined {
    return this.instruments.get(symbol)
  }

  getAll(): Instrument[] {
    return Array.from(this.instruments.values())
  }

  getByWorkerId(workerId: string): Instrument[] {
    return Array.from(this.instruments.values()).filter((i) => i.workerId === workerId)
  }
}

export const instrumentRegistry = new LocalInstrumentRegistry()

// Pre-register common instruments with worker partition
export async function initializeInstruments() {
  const instruments: Instrument[] = [
    {
      symbol: "BTC/USD",
      baseCurrency: "BTC",
      quoteCurrency: "USD",
      minOrderSize: 0.001,
      maxOrderSize: 100,
      priceTickSize: 0.01,
      workerId: "worker-0",
    },
    {
      symbol: "ETH/USD",
      baseCurrency: "ETH",
      quoteCurrency: "USD",
      minOrderSize: 0.01,
      maxOrderSize: 1000,
      priceTickSize: 0.01,
      workerId: "worker-1",
    },
    {
      symbol: "SOL/USD",
      baseCurrency: "SOL",
      quoteCurrency: "USD",
      minOrderSize: 0.1,
      maxOrderSize: 10000,
      priceTickSize: 0.001,
      workerId: "worker-1",
    },
    {
      symbol: "USDC/USD",
      baseCurrency: "USDC",
      quoteCurrency: "USD",
      minOrderSize: 1,
      maxOrderSize: 1000000,
      priceTickSize: 0.0001,
      workerId: "worker-2",
    },
  ]

  for (const instrument of instruments) {
    await instrumentRegistry.register(instrument)
  }
}
