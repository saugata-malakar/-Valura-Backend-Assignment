// Role-based API keys and rate limiting
export type ApiKeyRole = "viewer" | "trader" | "admin"

export interface ApiKey {
  key: string
  secret: string
  clientId: string
  role: ApiKeyRole
  rateLimit: number // requests per minute
  createdAt: number
  expiresAt?: number
  isActive: boolean
}

export interface RateLimitBucket {
  clientId: string
  requestCount: number
  windowStart: number
}

class ApiKeyManager {
  private apiKeys: Map<string, ApiKey> = new Map()
  private rateLimitBuckets: Map<string, RateLimitBucket> = new Map()
  private readonly WINDOW_DURATION = 60000 // 1 minute

  registerApiKey(clientId: string, role: ApiKeyRole, rateLimit = 100): ApiKey {
    const key = `key_${Math.random().toString(36).substring(7)}`
    const secret = `secret_${Math.random().toString(36).substring(7)}`

    const apiKey: ApiKey = {
      key,
      secret,
      clientId,
      role,
      rateLimit,
      createdAt: Date.now(),
      isActive: true,
    }

    this.apiKeys.set(key, apiKey)
    return apiKey
  }

  getApiKey(key: string): ApiKey | undefined {
    return this.apiKeys.get(key)
  }

  checkRateLimit(clientId: string, rateLimit: number): boolean {
    const now = Date.now()
    let bucket = this.rateLimitBuckets.get(clientId)

    if (!bucket || now - bucket.windowStart > this.WINDOW_DURATION) {
      bucket = { clientId, requestCount: 1, windowStart: now }
      this.rateLimitBuckets.set(clientId, bucket)
      return true
    }

    bucket.requestCount++
    return bucket.requestCount <= rateLimit
  }

  revokeApiKey(key: string): boolean {
    const apiKey = this.apiKeys.get(key)
    if (apiKey) {
      apiKey.isActive = false
      return true
    }
    return false
  }
}

export const apiKeyManager = new ApiKeyManager()
