// Settlement service - net positions per client at end of day
export interface Position {
  clientId: string
  symbol: string
  quantity: number
  avgPrice: number
  pnl: number
}

export interface Settlement {
  id: string
  clientId: string
  settlementDate: string
  positions: Position[]
  netCash: number
  status: "pending" | "completed" | "failed"
  createdAt: number
}

class SettlementService {
  private settlements: Map<string, Settlement> = new Map()
  private positions: Map<string, Position[]> = new Map()

  addPosition(clientId: string, position: Position): void {
    const key = clientId
    if (!this.positions.has(key)) {
      this.positions.set(key, [])
    }

    const existing = this.positions.get(key)!.find((p) => p.symbol === position.symbol)
    if (existing) {
      existing.quantity += position.quantity
      existing.avgPrice =
        (existing.avgPrice * existing.quantity + position.avgPrice * position.quantity) /
        (existing.quantity + position.quantity)
    } else {
      this.positions.get(key)!.push(position)
    }
  }

  getPositions(clientId: string): Position[] {
    return this.positions.get(clientId) || []
  }

  createSettlement(clientId: string): Settlement {
    const positions = this.getPositions(clientId)
    const settlementId = `settlement_${clientId}_${Date.now()}`
    const today = new Date().toISOString().split("T")[0]

    const settlement: Settlement = {
      id: settlementId,
      clientId,
      settlementDate: today,
      positions,
      netCash: positions.reduce((sum, p) => sum - p.pnl, 0),
      status: "pending",
      createdAt: Date.now(),
    }

    this.settlements.set(settlementId, settlement)
    return settlement
  }

  completeSettlement(settlementId: string): Settlement | undefined {
    const settlement = this.settlements.get(settlementId)
    if (settlement) {
      settlement.status = "completed"
    }
    return settlement
  }

  getSettlement(settlementId: string): Settlement | undefined {
    return this.settlements.get(settlementId)
  }

  getAllSettlements(clientId: string): Settlement[] {
    return Array.from(this.settlements.values()).filter((s) => s.clientId === clientId)
  }
}

export const settlementService = new SettlementService()
