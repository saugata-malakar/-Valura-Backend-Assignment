"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts"
import { TrendingUp, AlertCircle, Zap, Wifi } from "lucide-react"
import { generateMockOrderBook, generateMockTrade } from "@/lib/mock-data"

export default function Dashboard() {
  const [wsConnected, setWsConnected] = useState(true)
  const [trades, setTrades] = useState<any[]>([])
  const [orderBook, setOrderBook] = useState({ bids: [], asks: [] })
  const [latencyData, setLatencyData] = useState<any[]>([])
  const [throughput, setThroughput] = useState(0)
  const [selectedSymbol, setSelectedSymbol] = useState("BTC/USD")
  const latencyBufferRef = useRef<number[]>([])
  const tradeCountRef = useRef(0)
  const tradeTimerRef = useRef<NodeJS.Timeout>()
  const dataGeneratorRef = useRef<NodeJS.Timeout>()

  useEffect(() => {
    setWsConnected(true)
    setOrderBook(generateMockOrderBook())

    // Simulate continuous data flow
    dataGeneratorRef.current = setInterval(() => {
      // Update order book occasionally
      if (Math.random() > 0.7) {
        setOrderBook(generateMockOrderBook())
      }

      // Generate new trades
      if (Math.random() > 0.5) {
        const newTrade = generateMockTrade()
        const latency = Math.random() * 20 + 5 // 5-25ms latency
        latencyBufferRef.current.push(latency)
        if (latencyBufferRef.current.length > 100) latencyBufferRef.current.shift()

        setTrades((prev) => {
          const updated = [newTrade, ...prev].slice(0, 50)
          tradeCountRef.current++
          return updated
        })

        if (latencyBufferRef.current.length % 10 === 0) {
          const avg = Math.round(latencyBufferRef.current.reduce((a, b) => a + b) / latencyBufferRef.current.length)
          setLatencyData((prev) => [...prev.slice(-29), { time: new Date().toLocaleTimeString(), latency: avg }])
        }
      }
    }, 200)

    return () => {
      if (dataGeneratorRef.current) clearInterval(dataGeneratorRef.current)
    }
  }, [selectedSymbol])

  useEffect(() => {
    tradeTimerRef.current = setInterval(() => {
      setThroughput(tradeCountRef.current)
      tradeCountRef.current = 0
    }, 1000)

    return () => {
      if (tradeTimerRef.current) clearInterval(tradeTimerRef.current)
    }
  }, [])

  const p95Latency =
    latencyBufferRef.current.length > 0
      ? Math.round(
          [...latencyBufferRef.current].sort((a, b) => a - b)[Math.floor(latencyBufferRef.current.length * 0.95)],
        )
      : 0

  const p99Latency =
    latencyBufferRef.current.length > 0
      ? Math.round(
          [...latencyBufferRef.current].sort((a, b) => a - b)[Math.floor(latencyBufferRef.current.length * 0.99)],
        )
      : 0

  const avgLatency =
    latencyBufferRef.current.length > 0
      ? Math.round(latencyBufferRef.current.reduce((a, b) => a + b) / latencyBufferRef.current.length)
      : 0

  const bidTotal = orderBook.bids.reduce((sum, [_, qty]) => sum + Number.parseFloat(qty as string), 0)
  const askTotal = orderBook.asks.reduce((sum, [_, qty]) => sum + Number.parseFloat(qty as string), 0)

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background/90 p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold text-foreground">Trading Engine</h1>
          <p className="text-muted-foreground mt-2">Real-time order matching and market data</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-500/10 text-emerald-600 border border-emerald-200/30">
            <Wifi className="w-4 h-4" />
            <span className="text-sm font-medium">Live Demo</span>
          </div>
          <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></div>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="orderbook">Order Book</TabsTrigger>
          <TabsTrigger value="trades">Trade Feed</TabsTrigger>
          <TabsTrigger value="latency">Latency</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-card border-border hover:border-border/80 transition-colors">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Throughput</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3">
                  <Zap className="w-8 h-8 text-chart-1" />
                  <div>
                    <div className="text-3xl font-bold text-foreground">{throughput}</div>
                    <p className="text-xs text-muted-foreground">orders/sec</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border hover:border-border/80 transition-colors">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Avg Latency</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3">
                  <TrendingUp className="w-8 h-8 text-chart-2" />
                  <div>
                    <div className="text-3xl font-bold text-foreground">{avgLatency}</div>
                    <p className="text-xs text-muted-foreground">milliseconds</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border hover:border-border/80 transition-colors">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">P95 Latency</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3">
                  <TrendingUp className="w-8 h-8 text-chart-3" />
                  <div>
                    <div className="text-3xl font-bold text-foreground">{p95Latency}</div>
                    <p className="text-xs text-muted-foreground">milliseconds</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border hover:border-border/80 transition-colors">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">P99 Latency</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3">
                  <AlertCircle className="w-8 h-8 text-chart-4" />
                  <div>
                    <div className="text-3xl font-bold text-foreground">{p99Latency}</div>
                    <p className="text-xs text-muted-foreground">milliseconds</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>Real-time Latency Trend</CardTitle>
              <CardDescription>Average latency over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={latencyData}>
                  <defs>
                    <linearGradient id="colorLatency" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0.01} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <XAxis dataKey="time" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip className="rounded-lg border border-border bg-card text-foreground" />
                  <Area
                    type="monotone"
                    dataKey="latency"
                    stroke="hsl(var(--chart-1))"
                    fillOpacity={1}
                    fill="url(#colorLatency)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="orderbook" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base font-semibold">Bids</CardTitle>
                <CardDescription>Buy orders • {bidTotal.toFixed(2)} BTC volume</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-0 max-h-96 overflow-y-auto">
                  {orderBook.bids.slice(0, 20).map((bid, idx) => (
                    <div
                      key={idx}
                      className="flex justify-between text-sm p-3 hover:bg-emerald-500/5 rounded-md transition-colors border-b border-border/30 last:border-0"
                    >
                      <span className="text-emerald-500 font-mono font-semibold">${bid[0]}</span>
                      <span className="text-foreground font-mono">{bid[1]} BTC</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base font-semibold">Asks</CardTitle>
                <CardDescription>Sell orders • {askTotal.toFixed(2)} BTC volume</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-0 max-h-96 overflow-y-auto">
                  {orderBook.asks.slice(0, 20).map((ask, idx) => (
                    <div
                      key={idx}
                      className="flex justify-between text-sm p-3 hover:bg-red-500/5 rounded-md transition-colors border-b border-border/30 last:border-0"
                    >
                      <span className="text-red-500 font-mono font-semibold">${ask[0]}</span>
                      <span className="text-foreground font-mono">{ask[1]} BTC</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="trades" className="space-y-4">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>Recent Trades</CardTitle>
              <CardDescription>Last 50 executed trades on {selectedSymbol}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {trades.length === 0 ? (
                  <div className="flex items-center justify-center h-32 text-muted-foreground">
                    <p>Waiting for trades...</p>
                  </div>
                ) : (
                  trades.map((trade, idx) => (
                    <div
                      key={idx}
                      className="flex justify-between items-center p-3 bg-accent/40 hover:bg-accent/60 rounded-lg transition-colors border border-border/30"
                    >
                      <div className="flex-1">
                        <p className="text-sm font-medium text-foreground">{trade.symbol}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(trade.timestamp).toLocaleTimeString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p
                          className={`text-sm font-mono font-semibold ${trade.side === "buy" ? "text-emerald-500" : "text-red-500"}`}
                        >
                          {trade.side === "buy" ? "↑ BUY" : "↓ SELL"}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          ${trade.price} × {trade.quantity} BTC
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="latency" className="space-y-4">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>Latency Distribution</CardTitle>
              <CardDescription>Message processing latency across percentiles (milliseconds)</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart
                  data={[
                    { percentile: "P50", ms: avgLatency },
                    { percentile: "P95", ms: p95Latency },
                    { percentile: "P99", ms: p99Latency },
                  ]}
                >
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <XAxis dataKey="percentile" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip className="rounded-lg border border-border bg-card text-foreground" />
                  <Bar dataKey="ms" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
