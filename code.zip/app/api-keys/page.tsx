"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Copy, Trash2, Eye, EyeOff } from "lucide-react"

interface ApiKey {
  key: string
  secret: string
  clientId: string
  role: "viewer" | "trader" | "admin"
  rateLimit: number
  createdAt: number
  isActive: boolean
}

export default function ApiKeysPage() {
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([])
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({})
  const [loading, setLoading] = useState(false)
  const [newKeyForm, setNewKeyForm] = useState({
    clientId: "",
    role: "trader" as const,
    rateLimit: 100,
  })

  const createApiKey = async () => {
    if (!newKeyForm.clientId) {
      alert("Client ID is required")
      return
    }

    try {
      setLoading(true)
      const res = await fetch("/api/api-keys", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newKeyForm),
      })
      const data = await res.json()
      setApiKeys([...apiKeys, data])
      setNewKeyForm({ clientId: "", role: "trader", rateLimit: 100 })
    } catch (error) {
      console.error("Failed to create API key:", error)
    } finally {
      setLoading(false)
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const deleteApiKey = (key: string) => {
    setApiKeys(apiKeys.filter((k) => k.key !== key))
  }

  const toggleShowSecret = (key: string) => {
    setShowSecrets((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  return (
    <main className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        <div>
          <h1 className="text-4xl font-bold text-foreground mb-2">API Key Management</h1>
          <p className="text-muted-foreground">Create and manage API keys with role-based access control</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Create New API Key</CardTitle>
            <CardDescription>Generate new API keys for clients with specific roles and rate limits</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Client ID</label>
                <input
                  type="text"
                  value={newKeyForm.clientId}
                  onChange={(e) => setNewKeyForm({ ...newKeyForm, clientId: e.target.value })}
                  placeholder="client_001"
                  className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Role</label>
                <select
                  value={newKeyForm.role}
                  onChange={(e) => setNewKeyForm({ ...newKeyForm, role: e.target.value as any })}
                  className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground"
                >
                  <option value="viewer">Viewer</option>
                  <option value="trader">Trader</option>
                  <option value="admin">Admin</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Rate Limit (req/min)</label>
                <input
                  type="number"
                  value={newKeyForm.rateLimit}
                  onChange={(e) => setNewKeyForm({ ...newKeyForm, rateLimit: Number.parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground"
                />
              </div>

              <div className="flex items-end">
                <Button onClick={createApiKey} disabled={loading} className="w-full bg-green-600 hover:bg-green-700">
                  Generate Key
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Active API Keys</CardTitle>
            <CardDescription>Manage your API keys and permissions</CardDescription>
          </CardHeader>
          <CardContent>
            {apiKeys.length === 0 ? (
              <p className="text-muted-foreground">No API keys created yet</p>
            ) : (
              <div className="space-y-4">
                {apiKeys.map((apiKey) => (
                  <div key={apiKey.key} className="border border-border rounded-lg p-4 space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold text-foreground">{apiKey.clientId}</h3>
                        <p className="text-sm text-muted-foreground">
                          Created {new Date(apiKey.createdAt).toLocaleString()}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <span className="px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                          {apiKey.role}
                        </span>
                        <span className="px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-800">
                          {apiKey.rateLimit} req/min
                        </span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between bg-muted/50 p-3 rounded">
                        <code className="text-sm font-mono text-foreground">{apiKey.key}</code>
                        <Button size="sm" variant="ghost" onClick={() => copyToClipboard(apiKey.key)}>
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="flex items-center justify-between bg-muted/50 p-3 rounded">
                        <code className="text-sm font-mono text-foreground">
                          {showSecrets[apiKey.key] ? apiKey.secret : "••••••••••••••••"}
                        </code>
                        <div className="flex gap-2">
                          <Button size="sm" variant="ghost" onClick={() => toggleShowSecret(apiKey.key)}>
                            {showSecrets[apiKey.key] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => copyToClipboard(apiKey.secret)}>
                            <Copy className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <Button size="sm" variant="destructive" onClick={() => deleteApiKey(apiKey.key)}>
                        <Trash2 className="w-4 h-4 mr-1" />
                        Revoke
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Role Permissions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="border border-border rounded-lg p-4">
                <h3 className="font-semibold text-foreground mb-2">Viewer</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>✓ View orders</li>
                  <li>✓ View trades</li>
                  <li>✓ View analytics</li>
                  <li>✗ Place orders</li>
                  <li>✗ Cancel orders</li>
                </ul>
              </div>

              <div className="border border-border rounded-lg p-4">
                <h3 className="font-semibold text-foreground mb-2">Trader</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>✓ View orders</li>
                  <li>✓ View trades</li>
                  <li>✓ Place orders</li>
                  <li>✓ Cancel orders</li>
                  <li>✗ Manage keys</li>
                </ul>
              </div>

              <div className="border border-border rounded-lg p-4">
                <h3 className="font-semibold text-foreground mb-2">Admin</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>✓ All permissions</li>
                  <li>✓ Manage clients</li>
                  <li>✓ Manage keys</li>
                  <li>✓ Settlement</li>
                  <li>✓ Analytics</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
