import { instrumentRegistry, initializeInstruments } from "@/lib/instruments"
import { type NextRequest, NextResponse } from "next/server"

// Initialize on first request
let initialized = false

async function ensureInitialized() {
  if (!initialized) {
    await initializeInstruments()
    initialized = true
  }
}

export async function GET() {
  await ensureInitialized()
  const instruments = instrumentRegistry.getAll()
  return NextResponse.json(instruments)
}

export async function POST(request: NextRequest) {
  await ensureInitialized()
  const instrument = await request.json()
  await instrumentRegistry.register(instrument)
  return NextResponse.json(instrument, { status: 201 })
}
