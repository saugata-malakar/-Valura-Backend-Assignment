import { settlementService } from "@/lib/settlement"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const clientId = searchParams.get("clientId")

  if (!clientId) {
    return NextResponse.json({ error: "clientId required" }, { status: 400 })
  }

  const settlements = settlementService.getAllSettlements(clientId)
  return NextResponse.json(settlements)
}

export async function POST(request: NextRequest) {
  const { clientId } = await request.json()

  if (!clientId) {
    return NextResponse.json({ error: "clientId required" }, { status: 400 })
  }

  const settlement = settlementService.createSettlement(clientId)
  return NextResponse.json(settlement, { status: 201 })
}

export async function PUT(request: NextRequest) {
  const { settlementId } = await request.json()

  if (!settlementId) {
    return NextResponse.json({ error: "settlementId required" }, { status: 400 })
  }

  const settlement = settlementService.completeSettlement(settlementId)
  return NextResponse.json(settlement)
}
