import { NextResponse } from "next/server"

// Mock market data
function generateMockOrderBook() {
  return {
    bids: Array.from({ length: 15 }, (_, i) => [
      (50000 - i * 5 + (Math.random() - 0.5) * 10).toFixed(2),
      (Math.random() * 50 + 10).toFixed(4),
    ]),
    asks: Array.from({ length: 15 }, (_, i) => [
      (50005 + i * 5 + (Math.random() - 0.5) * 10).toFixed(2),
      (Math.random() * 50 + 10).toFixed(4),
    ]),
  }
}

function generateMockTrade() {
  return {
    id: Math.random().toString(36).substr(2, 9),
    symbol: "BTC/USD",
    side: Math.random() > 0.5 ? "buy" : "sell",
    price: (50000 + (Math.random() - 0.5) * 500).toFixed(2),
    quantity: (Math.random() * 2 + 0.1).toFixed(4),
    timestamp: Date.now(),
  }
}

export async function GET() {
  return NextResponse.json({
    orderBook: generateMockOrderBook(),
    trade: generateMockTrade(),
    status: "ok",
  })
}

export async function POST(request: Request) {
  const body = await request.json()

  if (body.action === "get_orderbook") {
    return NextResponse.json({
      type: "orderbook",
      payload: generateMockOrderBook(),
    })
  }

  if (body.action === "place_order") {
    return NextResponse.json({
      type: "trade",
      payload: generateMockTrade(),
    })
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400 })
}
