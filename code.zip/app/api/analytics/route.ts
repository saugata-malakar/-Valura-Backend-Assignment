import { analyticsEngine } from "@/lib/analytics"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const symbol = searchParams.get("symbol")
  const metric = searchParams.get("metric") // 'vwap', '1min', '5min'
  const startTime = Number.parseInt(searchParams.get("startTime") || "0")
  const endTime = Number.parseInt(searchParams.get("endTime") || String(Date.now()))

  if (!symbol || !metric) {
    return NextResponse.json({ error: "symbol and metric parameters required" }, { status: 400 })
  }

  let result
  switch (metric) {
    case "vwap":
      result = analyticsEngine.getVWAP(symbol, startTime, endTime)
      break
    case "1min":
      result = analyticsEngine.aggregate1Min(symbol)
      break
    case "5min":
      result = analyticsEngine.aggregate5Min(symbol)
      break
    default:
      return NextResponse.json({ error: "Invalid metric" }, { status: 400 })
  }

  return NextResponse.json(result)
}
