import { apiKeyManager } from "@/lib/api-keys"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  const { clientId, role, rateLimit } = await request.json()

  if (!clientId || !role) {
    return NextResponse.json({ error: "clientId and role required" }, { status: 400 })
  }

  const apiKey = apiKeyManager.registerApiKey(clientId, role, rateLimit || 100)
  return NextResponse.json(apiKey, { status: 201 })
}

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const key = searchParams.get("key")

  if (!key) {
    return NextResponse.json({ error: "key parameter required" }, { status: 400 })
  }

  const apiKey = apiKeyManager.getApiKey(key)
  if (!apiKey) {
    return NextResponse.json({ error: "API key not found" }, { status: 404 })
  }

  return NextResponse.json(apiKey)
}
