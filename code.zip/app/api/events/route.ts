import { eventStore, createEvent } from "@/lib/event-store"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const aggregateId = searchParams.get("aggregateId")
  const fromVersion = Number.parseInt(searchParams.get("fromVersion") || "0")

  if (!aggregateId) {
    return NextResponse.json({ error: "aggregateId required" }, { status: 400 })
  }

  const events = await eventStore.getEvents(aggregateId, fromVersion)
  return NextResponse.json(events)
}

export async function POST(request: NextRequest) {
  const { type, aggregateId, data, version } = await request.json()

  if (!type || !aggregateId) {
    return NextResponse.json({ error: "type and aggregateId required" }, { status: 400 })
  }

  const event = createEvent(type, aggregateId, data, version || 1)
  await eventStore.append(event)

  return NextResponse.json(event, { status: 201 })
}
