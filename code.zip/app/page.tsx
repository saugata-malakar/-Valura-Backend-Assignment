import Link from "next/link"
import { Button } from "@/components/ui/button"
import { BarChart3, Zap, Shield, TrendingUp, Database, Lock } from "lucide-react"

export default function Home() {
  return (
    <main className="flex flex-col min-h-screen bg-background">
      {/* Hero */}
      <section className="flex-1 flex items-center justify-center px-4 py-16 md:py-24">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <div className="space-y-4">
            <h1 className="text-5xl md:text-6xl font-bold text-foreground text-balance">
              Enterprise-Grade Cryptocurrency Exchange
            </h1>
            <p className="text-xl text-muted-foreground text-balance">
              Scalable trading engine with event-sourcing, multi-instrument support, and real-time analytics
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/admin">
              <Button size="lg" className="bg-primary hover:bg-primary/90">
                <BarChart3 className="w-5 h-5 mr-2" />
                Admin Dashboard
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button size="lg" variant="outline">
                <Zap className="w-5 h-5 mr-2" />
                Trading Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="bg-card border-t border-border py-16 md:py-24">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-12 text-center">Core Features</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Database,
                title: "Event-Sourcing",
                description:
                  "Persist all events and derive state through deterministic replay for perfect auditability",
              },
              {
                icon: TrendingUp,
                title: "Multi-Instrument",
                description: "Support unlimited trading pairs with partition-based matching workers for scalability",
              },
              {
                icon: Lock,
                title: "Settlement",
                description: "Daily settlement service with automatic position netting per client",
              },
              {
                icon: Shield,
                title: "API Security",
                description: "Role-based API keys with granular rate limiting per client",
              },
              {
                icon: Zap,
                title: "Real-time Analytics",
                description: "VWAP, 1-minute and 5-minute candles, and market aggregates on demand",
              },
              {
                icon: BarChart3,
                title: "Performance",
                description: "2000+ orders/sec throughput with <50ms P99 latency",
              },
            ].map((feature, i) => {
              const Icon = feature.icon
              return (
                <div key={i} className="bg-background border border-border rounded-lg p-6 space-y-3">
                  <Icon className="w-8 h-8 text-primary" />
                  <h3 className="text-lg font-semibold text-foreground">{feature.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{feature.description}</p>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* System Architecture */}
      <section className="bg-background py-16 md:py-24">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-12 text-center">System Architecture</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="border border-border rounded-lg p-6 bg-card">
              <h3 className="text-xl font-semibold text-foreground mb-4">Backend Services</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary">►</span>
                  <span>Event Store with aggregate snapshots</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">►</span>
                  <span>Partitioned matching engine (3+ workers)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">►</span>
                  <span>Order book management by symbol</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">►</span>
                  <span>Settlement & position tracking service</span>
                </li>
              </ul>
            </div>

            <div className="border border-border rounded-lg p-6 bg-card">
              <h3 className="text-xl font-semibold text-foreground mb-4">API & Analytics</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary">►</span>
                  <span>REST API for orders, trades, and analytics</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">►</span>
                  <span>WebSocket streaming of order books & trades</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">►</span>
                  <span>VWAP and trade aggregate calculations</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">►</span>
                  <span>Rate limiting & API key management</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-primary text-primary-foreground py-16 md:py-24">
        <div className="max-w-2xl mx-auto text-center space-y-6 px-4">
          <h2 className="text-3xl md:text-4xl font-bold">Ready to Get Started?</h2>
          <p className="text-lg opacity-90">Explore the fully functional trading dashboard and admin interfaces</p>
          <Link href="/admin">
            <Button
              size="lg"
              variant="outline"
              className="border-primary-foreground text-primary hover:bg-primary-foreground hover:text-primary bg-transparent"
            >
              Access Admin Dashboard
            </Button>
          </Link>
        </div>
      </section>
    </main>
  )
}
