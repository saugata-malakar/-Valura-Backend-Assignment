"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ComposedChart } from "recharts"

interface TradeAggregate {
  symbol: string
  timestamp: number
  open: number
  high: number
  low: number
  close: number
  volume: number
  vwap: number
}

export default function AnalyticsPage() {
  const [symbol, setSymbol] = useState("BTC/USD")
  const [metric, setMetric] = useState<"1min" | "5min" | "vwap">("1min")
  const [data, setData] = useState<any[]>([])
  const [vwap, setVwap] = useState<number | null>(null)
  const [loading, setLoading] = useState(false)
  const [selectedSymbol, setSelectedSymbol] = useState("BTC/USD")

  const instruments = ["BTC/USD", "ETH/USD", "SOL/USD", "USDC/USD"]

  const fetchAnalytics = async (metric: string) => {
    try {
      setLoading(true)
      const now = Date.now()
      const startTime = now - 86400000 // Last 24 hours

      const res = await fetch(
        `/api/analytics?symbol=${selectedSymbol}&metric=${metric}&startTime=${startTime}&endTime=${now}`,
      )
      const data = await res.json()

      if (metric === "vwap") {
        setVwap(data)
      } else {
        setData(
          data.map((item: any) => ({
            ...item,
            time: new Date(item.timestamp).toLocaleTimeString(),
          })),
        )
      }
    } catch (error) {
      console.error("Failed to fetch analytics:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchAnalytics(metric)
  }, [selectedSymbol, metric])

  // Mock data for demo
  const mockData = [
    { time: "09:00", open: 45000, high: 45500, low: 44800, close: 45200, volume: 1200, vwap: 45100 },
    { time: "09:05", open: 45200, high: 45700, low: 45000, close: 45500, volume: 1400, vwap: 45350 },
    { time: "09:10", open: 45500, high: 46000, low: 45300, close: 45800, volume: 1600, vwap: 45600 },
    { time: "09:15", open: 45800, high: 46200, low: 45600, close: 45900, volume: 1800, vwap: 45850 },
    { time: "09:20", open: 45900, high: 46300, low: 45700, close: 46100, volume: 2000, vwap: 46000 },
    { time: "09:25", open: 46100, high: 46500, low: 45900, close: 46300, volume: 2200, vwap: 46150 },
    { time: "09:30", open: 46300, high: 46600, low: 46000, close: 46400, volume: 2400, vwap: 46250 },
  ]

  const displayData = data.length > 0 ? data : mockData
  const avgPrice = displayData.reduce((sum, item) => sum + item.close, 0) / displayData.length
  const maxPrice = Math.max(...displayData.map((item) => item.high))
  const minPrice = Math.min(...displayData.map((item) => item.low))
  const totalVolume = displayData.reduce((sum, item) => sum + item.volume, 0)

  return (
    <main className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        <div>
          <h1 className="text-4xl font-bold text-foreground mb-2">Trading Analytics</h1>
          <p className="text-muted-foreground">VWAP, price aggregates, and market analysis</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Analytics Controls</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Symbol</label>
                <select
                  value={selectedSymbol}
                  onChange={(e) => setSelectedSymbol(e.target.value)}
                  className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground"
                >
                  {instruments.map((inst) => (
                    <option key={inst} value={inst}>
                      {inst}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Metric</label>
                <select
                  value={metric}
                  onChange={(e) => setMetric(e.target.value as any)}
                  className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground"
                >
                  <option value="1min">1-Min Candles</option>
                  <option value="5min">5-Min Candles</option>
                  <option value="vwap">VWAP</option>
                </select>
              </div>

              <div className="flex items-end">
                <Button onClick={() => fetchAnalytics(metric)} disabled={loading} className="w-full">
                  Refresh
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Average Price</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">${avgPrice.toFixed(2)}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">High</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">${maxPrice.toFixed(2)}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Low</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-red-600">${minPrice.toFixed(2)}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Volume</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{totalVolume}</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>
              {selectedSymbol} - {metric === "1min" ? "1-Minute" : metric === "5min" ? "5-Minute" : "VWAP"} Chart
            </CardTitle>
            <CardDescription>Price action and volume analysis</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={400}>
              <ComposedChart data={displayData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis yAxisId="left" />
                <YAxis yAxisId="right" orientation="right" />
                <Tooltip />
                <Legend />
                <Bar yAxisId="right" dataKey="volume" fill="rgba(100, 150, 200, 0.3)" name="Volume" />
                <Line
                  yAxisId="left"
                  type="monotone"
                  dataKey="close"
                  stroke="hsl(var(--chart-1))"
                  name="Close"
                  strokeWidth={2}
                />
                <Line
                  yAxisId="left"
                  type="monotone"
                  dataKey="vwap"
                  stroke="hsl(var(--chart-2))"
                  name="VWAP"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                />
              </ComposedChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Candlestick Data</CardTitle>
            <CardDescription>Detailed price movements by timeframe</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border">
                  <tr className="text-muted-foreground">
                    <th className="text-left py-2 px-4">Time</th>
                    <th className="text-right py-2 px-4">Open</th>
                    <th className="text-right py-2 px-4">High</th>
                    <th className="text-right py-2 px-4">Low</th>
                    <th className="text-right py-2 px-4">Close</th>
                    <th className="text-right py-2 px-4">Volume</th>
                    <th className="text-right py-2 px-4">VWAP</th>
                  </tr>
                </thead>
                <tbody>
                  {displayData.map((item, i) => (
                    <tr key={i} className="border-b border-border hover:bg-muted/50">
                      <td className="py-2 px-4 text-foreground">{item.time}</td>
                      <td className="py-2 px-4 text-right text-foreground">${item.open.toFixed(2)}</td>
                      <td className="py-2 px-4 text-right text-green-600">${item.high.toFixed(2)}</td>
                      <td className="py-2 px-4 text-right text-red-600">${item.low.toFixed(2)}</td>
                      <td className="py-2 px-4 text-right text-foreground font-semibold">${item.close.toFixed(2)}</td>
                      <td className="py-2 px-4 text-right text-muted-foreground">{item.volume}</td>
                      <td className="py-2 px-4 text-right text-foreground">${item.vwap.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
