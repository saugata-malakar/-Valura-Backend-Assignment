"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { Zap, Users, TrendingUp, Database, Shield } from "lucide-react"

interface DashboardStats {
  totalOrders: number
  activeConnections: number
  throughput: number
  avgLatency: number
  totalTrades: number
  systemHealth: number
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalOrders: 12540,
    activeConnections: 342,
    throughput: 1842,
    avgLatency: 23.5,
    totalTrades: 8423,
    systemHealth: 98.7,
  })

  const [eventCount, setEventCount] = useState(0)
  const [instrumentCount, setInstrumentCount] = useState(4)

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      setStats((prev) => ({
        ...prev,
        totalOrders: prev.totalOrders + Math.floor(Math.random() * 50),
        throughput: 1800 + Math.floor(Math.random() * 200),
        avgLatency: 20 + Math.random() * 10,
        activeConnections: 300 + Math.floor(Math.random() * 100),
      }))
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  const throughputData = [
    { time: "00:00", orders: 1200, trades: 800 },
    { time: "04:00", orders: 1400, trades: 950 },
    { time: "08:00", orders: 2100, trades: 1400 },
    { time: "12:00", orders: 2800, trades: 1900 },
    { time: "16:00", orders: 2300, trades: 1600 },
    { time: "20:00", orders: 1800, trades: 1200 },
    { time: "23:59", orders: 1200, trades: 800 },
  ]

  const systemMetrics = [
    { name: "API Keys", value: 45, color: "#3b82f6" },
    { name: "Active Clients", value: 32, color: "#10b981" },
    { name: "Pending Settlements", value: 8, color: "#f59e0b" },
    { name: "Instruments", value: 4, color: "#8b5cf6" },
  ]

  const menuItems = [
    {
      title: "Trading Dashboard",
      description: "Real-time order book and trade feed",
      href: "/dashboard",
      icon: TrendingUp,
      color: "bg-blue-500",
    },
    {
      title: "Settlement",
      description: "Manage daily settlements and positions",
      href: "/settlement",
      icon: Database,
      color: "bg-green-500",
    },
    {
      title: "API Keys",
      description: "Role-based access control and rate limits",
      href: "/api-keys",
      icon: Shield,
      color: "bg-purple-500",
    },
    {
      title: "Analytics",
      description: "VWAP, aggregates, and market analysis",
      href: "/analytics",
      icon: TrendingUp,
      color: "bg-orange-500",
    },
  ]

  return (
    <main className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-4xl font-bold text-foreground mb-2">Exchange Admin Dashboard</h1>
          <p className="text-muted-foreground">Real-time monitoring and control of trading infrastructure</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Zap className="w-4 h-4" />
                Throughput
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{stats.throughput}</div>
              <p className="text-xs text-muted-foreground mt-1">orders/sec</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Users className="w-4 h-4" />
                Active Connections
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{stats.activeConnections}</div>
              <p className="text-xs text-muted-foreground mt-1">connected clients</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Avg Latency</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{stats.avgLatency.toFixed(1)}</div>
              <p className="text-xs text-muted-foreground mt-1">milliseconds</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">System Health</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-3xl font-bold ${stats.systemHealth > 95 ? "text-green-600" : "text-yellow-600"}`}>
                {stats.systemHealth.toFixed(1)}%
              </div>
              <p className="text-xs text-muted-foreground mt-1">operational</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Navigation */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {menuItems.map((item) => {
            const Icon = item.icon
            return (
              <Link key={item.href} href={item.href}>
                <Card className="hover:bg-muted/50 cursor-pointer transition-colors h-full">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{item.title}</CardTitle>
                        <CardDescription>{item.description}</CardDescription>
                      </div>
                      <div className={`${item.color} p-2 rounded-lg`}>
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                    </div>
                  </CardHeader>
                </Card>
              </Link>
            )
          })}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle>Order & Trade Throughput</CardTitle>
              <CardDescription>24-hour order and trade volume</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={throughputData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="orders" fill="hsl(var(--chart-1))" />
                  <Bar dataKey="trades" fill="hsl(var(--chart-2))" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>System Composition</CardTitle>
              <CardDescription>Distribution across key components</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={systemMetrics}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {systemMetrics.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* System Status */}
        <Card>
          <CardHeader>
            <CardTitle>System Status</CardTitle>
            <CardDescription>Real-time infrastructure health</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="border border-border rounded-lg p-4">
                <h3 className="font-semibold text-foreground mb-2">API Service</h3>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm text-muted-foreground">Operational</span>
                </div>
              </div>

              <div className="border border-border rounded-lg p-4">
                <h3 className="font-semibold text-foreground mb-2">Matching Engine</h3>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm text-muted-foreground">Operational</span>
                </div>
              </div>

              <div className="border border-border rounded-lg p-4">
                <h3 className="font-semibold text-foreground mb-2">Database</h3>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm text-muted-foreground">Operational</span>
                </div>
              </div>

              <div className="border border-border rounded-lg p-4">
                <h3 className="font-semibold text-foreground mb-2">Event Store</h3>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm text-muted-foreground">Operational</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Events */}
        <Card>
          <CardHeader>
            <CardTitle>System Information</CardTitle>
            <CardDescription>Current deployment configuration</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">Total Orders</p>
                <p className="font-semibold text-foreground text-lg">{stats.totalOrders}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Total Trades</p>
                <p className="font-semibold text-foreground text-lg">{stats.totalTrades}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Instruments</p>
                <p className="font-semibold text-foreground text-lg">{instrumentCount}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Event Count</p>
                <p className="font-semibold text-foreground text-lg">{eventCount}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
