"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

interface Settlement {
  id: string
  clientId: string
  settlementDate: string
  positions: Array<{ symbol: string; quantity: number; avgPrice: number; pnl: number }>
  netCash: number
  status: "pending" | "completed" | "failed"
  createdAt: number
}

interface Position {
  clientId: string
  symbol: string
  quantity: number
  avgPrice: number
  pnl: number
}

export default function SettlementPage() {
  const [clientId, setClientId] = useState("client_001")
  const [settlements, setSettlements] = useState<Settlement[]>([])
  const [positions, setPositions] = useState<Position[]>([])
  const [loading, setLoading] = useState(false)

  const fetchSettlements = async () => {
    try {
      setLoading(true)
      const res = await fetch(`/api/settlement?clientId=${clientId}`)
      const data = await res.json()
      setSettlements(data)
    } catch (error) {
      console.error("Failed to fetch settlements:", error)
    } finally {
      setLoading(false)
    }
  }

  const createSettlement = async () => {
    try {
      setLoading(true)
      const res = await fetch("/api/settlement", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ clientId }),
      })
      const data = await res.json()
      setSettlements([...settlements, data])
    } catch (error) {
      console.error("Failed to create settlement:", error)
    } finally {
      setLoading(false)
    }
  }

  const completeSettlement = async (settlementId: string) => {
    try {
      const res = await fetch("/api/settlement", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ settlementId }),
      })
      const data = await res.json()
      setSettlements(settlements.map((s) => (s.id === settlementId ? data : s)))
    } catch (error) {
      console.error("Failed to complete settlement:", error)
    }
  }

  useEffect(() => {
    if (clientId) {
      fetchSettlements()
    }
  }, [clientId])

  const pnlBySymbol = settlements
    .flatMap((s) => s.positions)
    .reduce((acc, pos) => {
      const existing = acc.find((p) => p.symbol === pos.symbol)
      if (existing) {
        existing.pnl += pos.pnl
        existing.quantity += pos.quantity
      } else {
        acc.push(pos)
      }
      return acc
    }, [] as Position[])

  const totalPnL = pnlBySymbol.reduce((sum, p) => sum + p.pnl, 0)
  const totalPositions = pnlBySymbol.length

  const chartData = pnlBySymbol.map((p) => ({
    symbol: p.symbol,
    pnl: p.pnl,
  }))

  return (
    <main className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        <div>
          <h1 className="text-4xl font-bold text-foreground mb-2">Settlement Management</h1>
          <p className="text-muted-foreground">Track client positions and daily settlements</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Settlement Controls</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4 items-end">
              <div className="flex-1">
                <label className="block text-sm font-medium text-foreground mb-2">Client ID</label>
                <input
                  type="text"
                  value={clientId}
                  onChange={(e) => setClientId(e.target.value)}
                  className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground"
                />
              </div>
              <Button onClick={fetchSettlements} disabled={loading}>
                Refresh
              </Button>
              <Button onClick={createSettlement} disabled={loading} className="bg-green-600 hover:bg-green-700">
                Create Settlement
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total P&L</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-3xl font-bold ${totalPnL >= 0 ? "text-green-600" : "text-red-600"}`}>
                ${totalPnL.toFixed(2)}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Positions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{totalPositions}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Settlements</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{settlements.length}</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>P&L by Symbol</CardTitle>
            <CardDescription>Profit and loss across all positions</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="symbol" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="pnl" fill="hsl(var(--chart-1))" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Settlements</CardTitle>
            <CardDescription>History of all settlements for this client</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {settlements.length === 0 ? (
                <p className="text-muted-foreground">No settlements found</p>
              ) : (
                settlements.map((settlement) => (
                  <div key={settlement.id} className="border border-border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="font-semibold text-foreground">{settlement.settlementDate}</h3>
                        <p className="text-sm text-muted-foreground">ID: {settlement.id}</p>
                      </div>
                      <div className="flex gap-2 items-center">
                        <span
                          className={`px-3 py-1 rounded-full text-sm font-medium ${
                            settlement.status === "completed"
                              ? "bg-green-100 text-green-800"
                              : settlement.status === "pending"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-red-100 text-red-800"
                          }`}
                        >
                          {settlement.status}
                        </span>
                        {settlement.status === "pending" && (
                          <Button
                            size="sm"
                            onClick={() => completeSettlement(settlement.id)}
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            Complete
                          </Button>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <p className="text-muted-foreground">Net Cash</p>
                        <p className="font-semibold text-foreground">${settlement.netCash.toFixed(2)}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Positions</p>
                        <p className="font-semibold text-foreground">{settlement.positions.length}</p>
                      </div>
                    </div>

                    {settlement.positions.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-border space-y-1">
                        {settlement.positions.map((pos, i) => (
                          <div key={i} className="flex justify-between text-xs">
                            <span className="text-muted-foreground">{pos.symbol}</span>
                            <span className="font-medium text-foreground">
                              {pos.quantity} @ ${pos.avgPrice.toFixed(2)} | P&L: ${pos.pnl.toFixed(2)}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
