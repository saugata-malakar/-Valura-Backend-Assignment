# Operator Dashboard Guide

The operator dashboard provides real-time monitoring and control of the exchange backend.

## Accessing the Dashboard

### Local Development
\`\`\`bash
# Access web dashboard
http://localhost:3001

# Access Prometheus metrics
http://localhost:9091

# Access Grafana dashboards
http://localhost:3000 (admin/admin)
\`\`\`

### Key Metrics

#### Orders
- **orders_placed_total** - Total orders by symbol and side
- **orders_cancelled_total** - Total cancellations
- **order_latency_ms** - P50/P95/P99 latencies

#### Trades
- **trades_executed_total** - Total trades by symbol
- **trade_volume_total** - Total volume by symbol

#### System Health
- **orderbook_depth** - Current depth (bids/asks)
- **active_connections** - Live WebSocket connections
- **queue_depth** - Pending orders in queue

#### Performance
- **matching_latency_ms** - Order matching duration
- **queue_processing_time_ms** - Time to process queue

## Operations

### Create Snapshot
Manually trigger a snapshot for deterministic recovery:
\`\`\`bash
POST /api/dashboard/snapshot
\`\`\`

### Export Metrics
Download Prometheus metrics in text format:
\`\`\`bash
curl http://localhost:9090/metrics > metrics.txt
\`\`\`

### Query Examples

**Get order count by symbol (last 1h)**
\`\`\`promql
rate(orders_placed_total[1h])
