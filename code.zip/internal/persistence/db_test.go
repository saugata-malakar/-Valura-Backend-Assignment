package persistence

import (
	"context"
	"testing"

	"exchange-backend/internal/engine"
)

func TestOrderRepositorySave(t *testing.T) {
	db, err := NewDB("host=localhost user=exchange_user password=exchange_pass dbname=exchange_test sslmode=disable")
	if err != nil {
		t.Skipf("Database not available: %v", err)
	}
	defer db.Close()

	RunMigrations(db)
	repo := NewOrderRepository(db)

	order := &engine.Order{
		ID:       "test-1",
		UserID:   "user1",
		Symbol:   "BTC/USD",
		Side:     engine.Buy,
		Price:    50000,
		Quantity: 1.0,
		Filled:   0,
		Status:   engine.Pending,
	}

	err = repo.Save(context.Background(), order)
	if err != nil {
		t.Fatalf("Failed to save order: %v", err)
	}

	retrieved, err := repo.FindByID(context.Background(), "test-1")
	if err != nil {
		t.Fatalf("Failed to retrieve order: %v", err)
	}

	if retrieved.ID != order.ID {
		t.Errorf("Order ID mismatch: got %s, want %s", retrieved.ID, order.ID)
	}
}

func TestTradeRepositorySave(t *testing.T) {
	db, err := NewDB("host=localhost user=exchange_user password=exchange_pass dbname=exchange_test sslmode=disable")
	if err != nil {
		t.Skipf("Database not available: %v", err)
	}
	defer db.Close()

	RunMigrations(db)
	repo := NewTradeRepository(db)

	trade := &engine.Trade{
		ID:          "trade-1",
		Symbol:      "BTC/USD",
		BuyOrderID:  "buy-1",
		SellOrderID: "sell-1",
		Price:       50000,
		Quantity:    1.0,
	}

	err = repo.Save(context.Background(), trade)
	if err != nil {
		t.Fatalf("Failed to save trade: %v", err)
	}

	trades, err := repo.FindBySymbol(context.Background(), "BTC/USD", 10, 0)
	if err != nil {
		t.Fatalf("Failed to retrieve trades: %v", err)
	}

	if len(trades) != 1 {
		t.Errorf("Expected 1 trade, got %d", len(trades))
	}
}
