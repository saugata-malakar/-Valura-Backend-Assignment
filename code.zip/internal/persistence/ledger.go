package persistence

import (
	"context"
	"database/sql"
	"encoding/json"
	"time"

	"exchange-backend/internal/engine"
)

type Ledger struct {
	db *sql.DB
}

func NewLedger(db *sql.DB) *Ledger {
	return &Ledger{db: db}
}

func (l *Ledger) RecordOrderSnapshot(ctx context.Context, snapshot *engine.Snapshot) error {
	query := `
	INSERT INTO snapshots (symbol, snapshot_data, created_at)
	VALUES ($1, $2, $3)
	`
	data, err := json.Marshal(snapshot)
	if err != nil {
		return err
	}

	_, err = l.db.ExecContext(ctx, query, "SYSTEM", string(data), time.Now().UnixNano())
	return err
}

func (l *Ledger) GetLatestSnapshot(ctx context.Context) (*engine.Snapshot, error) {
	query := `
	SELECT snapshot_data FROM snapshots
	ORDER BY created_at DESC
	LIMIT 1
	`
	var data string
	err := l.db.QueryRowContext(ctx, query).Scan(&data)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}

	snapshot := &engine.Snapshot{}
	err = json.Unmarshal([]byte(data), snapshot)
	return snapshot, err
}

func (l *Ledger) RecordJournalEntry(ctx context.Context, entry *engine.JournalEntry) error {
	query := `
	INSERT INTO journal (entry_type, entry_data, created_at)
	VALUES ($1, $2, $3)
	`
	data, err := json.Marshal(entry)
	if err != nil {
		return err
	}

	_, err = l.db.ExecContext(ctx, query, entry.Type, string(data), entry.Timestamp)
	return err
}

func (l *Ledger) GetJournalSince(ctx context.Context, since int64) ([]*engine.JournalEntry, error) {
	query := `
	SELECT entry_data FROM journal
	WHERE created_at > $1
	ORDER BY created_at ASC
	`
	rows, err := l.db.QueryContext(ctx, query, since)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var entries []*engine.JournalEntry
	for rows.Next() {
		var data string
		err := rows.Scan(&data)
		if err != nil {
			return nil, err
		}
		entry := &engine.JournalEntry{}
		err = json.Unmarshal([]byte(data), entry)
		if err != nil {
			return nil, err
		}
		entries = append(entries, entry)
	}
	return entries, rows.Err()
}
