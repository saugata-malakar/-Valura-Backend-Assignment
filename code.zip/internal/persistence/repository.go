package persistence

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"exchange-backend/internal/engine"
)

type OrderRepository struct {
	db *sql.DB
}

type TradeRepository struct {
	db *sql.DB
}

func NewOrderRepository(db *sql.DB) *OrderRepository {
	return &OrderRepository{db: db}
}

func NewTradeRepository(db *sql.DB) *TradeRepository {
	return &TradeRepository{db: db}
}

func (r *OrderRepository) Save(ctx context.Context, order *engine.Order) error {
	query := `
	INSERT INTO orders (id, user_id, symbol, side, price, quantity, filled, status, created_at, updated_at)
	VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
	ON CONFLICT (id) DO UPDATE SET
		filled = $7,
		status = $8,
		updated_at = $10
	`
	_, err := r.db.ExecContext(ctx, query,
		order.ID, order.UserID, order.Symbol, order.Side,
		order.Price, order.Quantity, order.Filled, order.Status,
		order.Timestamp, time.Now().UnixNano(),
	)
	return err
}

func (r *OrderRepository) FindByID(ctx context.Context, id string) (*engine.Order, error) {
	query := `
	SELECT id, user_id, symbol, side, price, quantity, filled, status, created_at
	FROM orders WHERE id = $1
	`
	order := &engine.Order{}
	err := r.db.QueryRowContext(ctx, query, id).Scan(
		&order.ID, &order.UserID, &order.Symbol, &order.Side,
		&order.Price, &order.Quantity, &order.Filled, &order.Status, &order.Timestamp,
	)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	return order, err
}

func (r *OrderRepository) FindByUserID(ctx context.Context, userID string, limit int, offset int) ([]*engine.Order, error) {
	query := `
	SELECT id, user_id, symbol, side, price, quantity, filled, status, created_at
	FROM orders WHERE user_id = $1
	ORDER BY created_at DESC
	LIMIT $2 OFFSET $3
	`
	rows, err := r.db.QueryContext(ctx, query, userID, limit, offset)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var orders []*engine.Order
	for rows.Next() {
		order := &engine.Order{}
		err := rows.Scan(
			&order.ID, &order.UserID, &order.Symbol, &order.Side,
			&order.Price, &order.Quantity, &order.Filled, &order.Status, &order.Timestamp,
		)
		if err != nil {
			return nil, err
		}
		orders = append(orders, order)
	}
	return orders, rows.Err()
}

func (r *OrderRepository) FindBySymbol(ctx context.Context, symbol string, status engine.OrderStatus) ([]*engine.Order, error) {
	query := `
	SELECT id, user_id, symbol, side, price, quantity, filled, status, created_at
	FROM orders WHERE symbol = $1 AND status = $2
	ORDER BY created_at DESC
	`
	rows, err := r.db.QueryContext(ctx, query, symbol, status)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var orders []*engine.Order
	for rows.Next() {
		order := &engine.Order{}
		err := rows.Scan(
			&order.ID, &order.UserID, &order.Symbol, &order.Side,
			&order.Price, &order.Quantity, &order.Filled, &order.Status, &order.Timestamp,
		)
		if err != nil {
			return nil, err
		}
		orders = append(orders, order)
	}
	return orders, rows.Err()
}

func (r *TradeRepository) Save(ctx context.Context, trade *engine.Trade) error {
	query := `
	INSERT INTO trades (id, symbol, buy_order_id, sell_order_id, price, quantity, created_at)
	VALUES ($1, $2, $3, $4, $5, $6, $7)
	`
	_, err := r.db.ExecContext(ctx, query,
		trade.ID, trade.Symbol, trade.BuyOrderID, trade.SellOrderID,
		trade.Price, trade.Quantity, trade.Timestamp,
	)
	return err
}

func (r *TradeRepository) FindBySymbol(ctx context.Context, symbol string, limit int, offset int) ([]*engine.Trade, error) {
	query := `
	SELECT id, symbol, buy_order_id, sell_order_id, price, quantity, created_at
	FROM trades WHERE symbol = $1
	ORDER BY created_at DESC
	LIMIT $2 OFFSET $3
	`
	rows, err := r.db.QueryContext(ctx, query, symbol, limit, offset)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var trades []*engine.Trade
	for rows.Next() {
		trade := &engine.Trade{}
		err := rows.Scan(
			&trade.ID, &trade.Symbol, &trade.BuyOrderID, &trade.SellOrderID,
			&trade.Price, &trade.Quantity, &trade.Timestamp,
		)
		if err != nil {
			return nil, err
		}
		trades = append(trades, trade)
	}
	return trades, rows.Err()
}

func (r *TradeRepository) FindSince(ctx context.Context, symbol string, since int64) ([]*engine.Trade, error) {
	query := `
	SELECT id, symbol, buy_order_id, sell_order_id, price, quantity, created_at
	FROM trades WHERE symbol = $1 AND created_at > $2
	ORDER BY created_at ASC
	`
	rows, err := r.db.QueryContext(ctx, query, symbol, since)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var trades []*engine.Trade
	for rows.Next() {
		trade := &engine.Trade{}
		err := rows.Scan(
			&trade.ID, &trade.Symbol, &trade.BuyOrderID, &trade.SellOrderID,
			&trade.Price, &trade.Quantity, &trade.Timestamp,
		)
		if err != nil {
			return nil, err
		}
		trades = append(trades, trade)
	}
	return trades, rows.Err()
}
