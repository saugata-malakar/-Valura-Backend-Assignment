package persistence

import (
	"database/sql"
	"fmt"

	_ "github.com/lib/pq"
)

func NewDB(connStr string) (*sql.DB, error) {
	if connStr == "" {
		connStr = "host=localhost user=exchange_user password=exchange_pass dbname=exchange sslmode=disable"
	}
	return sql.Open("postgres", connStr)
}

func RunMigrations(db *sql.DB) error {
	schema := `
	CREATE TABLE IF NOT EXISTS orders (
		id VARCHAR(255) PRIMARY KEY,
		user_id VARCHAR(255) NOT NULL,
		symbol VARCHAR(20) NOT NULL,
		side VARCHAR(10) NOT NULL,
		price DECIMAL(18, 8) NOT NULL,
		quantity DECIMAL(18, 8) NOT NULL,
		filled DECIMAL(18, 8) NOT NULL,
		status VARCHAR(20) NOT NULL,
		created_at BIGINT NOT NULL,
		updated_at BIGINT NOT NULL
	);

	CREATE TABLE IF NOT EXISTS trades (
		id VARCHAR(255) PRIMARY KEY,
		symbol VARCHAR(20) NOT NULL,
		buy_order_id VARCHAR(255) NOT NULL,
		sell_order_id VARCHAR(255) NOT NULL,
		price DECIMAL(18, 8) NOT NULL,
		quantity DECIMAL(18, 8) NOT NULL,
		created_at BIGINT NOT NULL,
		FOREIGN KEY (buy_order_id) REFERENCES orders(id),
		FOREIGN KEY (sell_order_id) REFERENCES orders(id)
	);

	-- added snapshots and journal tables for recovery
	CREATE TABLE IF NOT EXISTS snapshots (
		id SERIAL PRIMARY KEY,
		symbol VARCHAR(20) NOT NULL,
		snapshot_data TEXT NOT NULL,
		created_at BIGINT NOT NULL
	);

	CREATE TABLE IF NOT EXISTS journal (
		id SERIAL PRIMARY KEY,
		entry_type VARCHAR(50) NOT NULL,
		entry_data TEXT NOT NULL,
		created_at BIGINT NOT NULL
	);

	CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id);
	CREATE INDEX IF NOT EXISTS idx_orders_symbol ON orders(symbol);
	CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol);
	CREATE INDEX IF NOT EXISTS idx_trades_created_at ON trades(created_at);
	CREATE INDEX IF NOT EXISTS idx_snapshots_created_at ON snapshots(created_at DESC);
	CREATE INDEX IF NOT EXISTS idx_journal_created_at ON journal(created_at);
	`

	_, err := db.Exec(schema)
	return err
}
