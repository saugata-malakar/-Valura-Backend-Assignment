package metrics

import (
	"net/http"
	"sync"
	"time"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

var (
	// Order metrics
	OrdersPlaced = prometheus.NewCounterVec(
		prometheus.CounterOpts{Name: "orders_placed_total", Help: "Total orders placed"},
		[]string{"symbol", "side"},
	)
	OrdersCancelled = prometheus.NewCounterVec(
		prometheus.CounterOpts{Name: "orders_cancelled_total", Help: "Total orders cancelled"},
		[]string{"symbol"},
	)
	
	// Trade metrics
	TradesExecuted = prometheus.NewCounterVec(
		prometheus.CounterOpts{Name: "trades_executed_total", Help: "Total trades executed"},
		[]string{"symbol"},
	)
	TradeVolume = prometheus.NewCounterVec(
		prometheus.CounterOpts{Name: "trade_volume_total", Help: "Total trade volume"},
		[]string{"symbol"},
	)

	// Order book metrics
	OrderBookDepth = prometheus.NewGaugeVec(
		prometheus.GaugeOpts{Name: "orderbook_depth", Help: "Current order book depth"},
		[]string{"symbol", "side"},
	)
	
	// Latency metrics
	OrderLatency = prometheus.NewHistogramVec(
		prometheus.HistogramOpts{
			Name:    "order_latency_ms",
			Help:    "Order processing latency in milliseconds",
			Buckets: []float64{1, 5, 10, 25, 50, 100, 250, 500, 1000, 2000},
		},
		[]string{"symbol"},
	)
	MatchingLatency = prometheus.NewHistogramVec(
		prometheus.HistogramOpts{
			Name:    "matching_latency_ms",
			Help:    "Order matching latency in milliseconds",
			Buckets: []float64{0.1, 0.5, 1, 2, 5, 10, 25, 50},
		},
		[]string{"symbol"},
	)

	// Queue metrics
	QueueDepth = prometheus.NewGaugeVec(
		prometheus.GaugeOpts{Name: "queue_depth", Help: "Pending orders in queue"},
		[]string{"symbol"},
	)
	QueueProcessingTime = prometheus.NewHistogramVec(
		prometheus.HistogramOpts{
			Name:    "queue_processing_time_ms",
			Help:    "Time to process orders from queue",
			Buckets: []float64{1, 5, 10, 50, 100, 500},
		},
		[]string{"symbol"},
	)

	// Connection metrics
	ActiveConnections = prometheus.NewGauge(
		prometheus.GaugeOpts{Name: "active_connections", Help: "Number of active WebSocket connections"},
	)
	ConnectionsTotal = prometheus.NewCounter(
		prometheus.CounterOpts{Name: "connections_total", Help: "Total WebSocket connections"},
	)

	// System health metrics
	SystemErrors = prometheus.NewCounterVec(
		prometheus.CounterOpts{Name: "system_errors_total", Help: "Total system errors"},
		[]string{"error_type"},
	)
	DatabasePoolUtilization = prometheus.NewGauge(
		prometheus.GaugeOpts{Name: "db_pool_utilization", Help: "Database connection pool utilization"},
	)
)

func Init() {
	prometheus.MustRegister(
		OrdersPlaced,
		OrdersCancelled,
		TradesExecuted,
		TradeVolume,
		OrderBookDepth,
		OrderLatency,
		MatchingLatency,
		QueueDepth,
		QueueProcessingTime,
		ActiveConnections,
		ConnectionsTotal,
		SystemErrors,
		DatabasePoolUtilization,
	)
}

func Handler() http.Handler {
	return promhttp.Handler()
}

// MetricsCollector provides a thread-safe interface for updating metrics
type MetricsCollector struct {
	mu sync.RWMutex
}

var defaultCollector = &MetricsCollector{}

func RecordOrderPlaced(symbol string, side string) {
	OrdersPlaced.WithLabelValues(symbol, side).Inc()
}

func RecordOrderCancelled(symbol string) {
	OrdersCancelled.WithLabelValues(symbol).Inc()
}

func RecordTrade(symbol string, quantity float64) {
	TradesExecuted.WithLabelValues(symbol).Inc()
	TradeVolume.WithLabelValues(symbol).Add(quantity)
}

func RecordOrderLatency(symbol string, latencyMs float64) {
	OrderLatency.WithLabelValues(symbol).Observe(latencyMs)
}

func RecordMatchingLatency(symbol string, latencyMs float64) {
	MatchingLatency.WithLabelValues(symbol).Observe(latencyMs)
}

func UpdateOrderBookDepth(symbol string, bidCount, askCount int) {
	OrderBookDepth.WithLabelValues(symbol, "BID").Set(float64(bidCount))
	OrderBookDepth.WithLabelValues(symbol, "ASK").Set(float64(askCount))
}

func UpdateQueueDepth(symbol string, depth int) {
	QueueDepth.WithLabelValues(symbol).Set(float64(depth))
}

func RecordQueueProcessingTime(symbol string, timeMs float64) {
	QueueProcessingTime.WithLabelValues(symbol).Observe(timeMs)
}

func UpdateActiveConnections(count int) {
	ActiveConnections.Set(float64(count))
}

func RecordNewConnection() {
	ConnectionsTotal.Inc()
}

func RecordSystemError(errorType string) {
	SystemErrors.WithLabelValues(errorType).Inc()
}

func UpdateDatabasePoolUtilization(utilization float64) {
	DatabasePoolUtilization.Set(utilization)
}
