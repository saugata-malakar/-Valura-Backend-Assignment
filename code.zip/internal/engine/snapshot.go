package engine

import (
	"encoding/json"
	"time"
)

type Snapshot struct {
	Timestamp int64              `json:"timestamp"`
	Orders    map[string]*Order  `json:"orders"`
	Books     map[string]*OrderBook `json:"books"`
}

type JournalEntry struct {
	Type      string      `json:"type"` // "place_order", "cancel_order", "trade"
	Timestamp int64       `json:"timestamp"`
	Order     *Order      `json:"order,omitempty"`
	Trade     *Trade      `json:"trade,omitempty"`
	OrderID   string      `json:"order_id,omitempty"`
}

func (m *Matcher) CreateSnapshot() *Snapshot {
	m.mu.RLock()
	defer m.mu.RUnlock()

	snapshot := &Snapshot{
		Timestamp: time.Now().UnixNano(),
		Orders:    make(map[string]*Order),
		Books:     make(map[string]*OrderBook),
	}

	for symbol, book := range m.books {
		book.mu.RLock()
		snapshot.Books[symbol] = &OrderBook{
			Symbol: book.Symbol,
			Bids:   append([]*Order{}, book.Bids...),
			Asks:   append([]*Order{}, book.Asks...),
		}
		book.mu.RUnlock()
	}

	return snapshot
}

func (m *Matcher) RestoreSnapshot(snapshot *Snapshot) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	m.books = make(map[string]*OrderBook)

	for symbol, book := range snapshot.Books {
		newBook := &OrderBook{
			Symbol: symbol,
			Bids:   append([]*Order{}, book.Bids...),
			Asks:   append([]*Order{}, book.Asks...),
		}
		m.books[symbol] = newBook
	}

	return nil
}

func (s *Snapshot) Marshal() ([]byte, error) {
	return json.Marshal(s)
}

func (s *Snapshot) Unmarshal(data []byte) error {
	return json.Unmarshal(data, s)
}
