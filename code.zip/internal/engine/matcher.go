package engine

import (
	"fmt"
	"sort"
	"sync"
	"time"

	"github.com/google/uuid"
)

func NewMatcher() *Matcher {
	return &Matcher{
		books:  make(map[string]*OrderBook),
		trades: make(chan *Trade, 10000),
	}
}

func (m *Matcher) PlaceOrder(symbol string, side OrderSide, price, quantity float64, userID string) (*Order, error) {
	m.mu.Lock()
	book, exists := m.books[symbol]
	if !exists {
		book = &OrderBook{Symbol: symbol}
		m.books[symbol] = book
	}
	m.mu.Unlock()

	order := &Order{
		ID:        uuid.New().String(),
		Symbol:    symbol,
		Side:      side,
		Price:     price,
		Quantity:  quantity,
		Filled:    0,
		Status:    Pending,
		Timestamp: time.Now().UnixNano(),
		UserID:    userID,
	}

	// Match order against existing orders
	m.matchOrder(book, order)

	// Add remaining quantity to order book
	book.mu.Lock()
	if order.Filled < order.Quantity {
		if side == Buy {
			book.Bids = append(book.Bids, order)
			sort.SliceStable(book.Bids, func(i, j int) bool {
				if book.Bids[i].Price != book.Bids[j].Price {
					return book.Bids[i].Price > book.Bids[j].Price
				}
				return book.Bids[i].Timestamp < book.Bids[j].Timestamp
			})
		} else {
			book.Asks = append(book.Asks, order)
			sort.SliceStable(book.Asks, func(i, j int) bool {
				if book.Asks[i].Price != book.Asks[j].Price {
					return book.Asks[i].Price < book.Asks[j].Price
				}
				return book.Asks[i].Timestamp < book.Asks[j].Timestamp
			})
		}
		order.Status = PartialFilled
	}
	if order.Filled == order.Quantity {
		order.Status = Filled
	}
	book.mu.Unlock()

	return order, nil
}

func (m *Matcher) matchOrder(book *OrderBook, order *Order) {
	book.mu.Lock()
	defer book.mu.Unlock()

	remaining := order.Quantity - order.Filled

	if order.Side == Buy {
		// Match against asks
		for remaining > 0 && len(book.Asks) > 0 {
			ask := book.Asks[0]
			if ask.Price > order.Price {
				break
			}

			fillQty := remaining
			if ask.Quantity-ask.Filled < fillQty {
				fillQty = ask.Quantity - ask.Filled
			}

			// Create trade
			trade := &Trade{
				ID:         uuid.New().String(),
				Symbol:     order.Symbol,
				BuyOrderID:  order.ID,
				SellOrderID: ask.ID,
				Price:      ask.Price,
				Quantity:   fillQty,
				Timestamp:  time.Now().UnixNano(),
			}
			m.trades <- trade

			order.Filled += fillQty
			ask.Filled += fillQty
			remaining -= fillQty

			if ask.Filled == ask.Quantity {
				ask.Status = Filled
				book.Asks = append(book.Asks[:0], book.Asks[1:]...)
			}
		}
	} else {
		// Match against bids
		for remaining > 0 && len(book.Bids) > 0 {
			bid := book.Bids[0]
			if bid.Price < order.Price {
				break
			}

			fillQty := remaining
			if bid.Quantity-bid.Filled < fillQty {
				fillQty = bid.Quantity - bid.Filled
			}

			// Create trade
			trade := &Trade{
				ID:         uuid.New().String(),
				Symbol:     order.Symbol,
				BuyOrderID:  bid.ID,
				SellOrderID: order.ID,
				Price:      bid.Price,
				Quantity:   fillQty,
				Timestamp:  time.Now().UnixNano(),
			}
			m.trades <- trade

			order.Filled += fillQty
			bid.Filled += fillQty
			remaining -= fillQty

			if bid.Filled == bid.Quantity {
				bid.Status = Filled
				book.Bids = append(book.Bids[:0], book.Bids[1:]...)
			}
		}
	}
}

func (m *Matcher) CancelOrder(orderID string) error {
	m.mu.RLock()
	defer m.mu.RUnlock()

	for _, book := range m.books {
		book.mu.Lock()
		for i, bid := range book.Bids {
			if bid.ID == orderID {
				bid.Status = Cancelled
				book.Bids = append(book.Bids[:i], book.Bids[i+1:]...)
				book.mu.Unlock()
				return nil
			}
		}
		for i, ask := range book.Asks {
			if ask.ID == orderID {
				ask.Status = Cancelled
				book.Asks = append(book.Asks[:i], book.Asks[i+1:]...)
				book.mu.Unlock()
				return nil
			}
		}
		book.mu.Unlock()
	}

	return fmt.Errorf("order not found: %s", orderID)
}

func (m *Matcher) GetOrderBook(symbol string) *OrderBook {
	m.mu.RLock()
	book, exists := m.books[symbol]
	m.mu.RUnlock()

	if !exists {
		return nil
	}

	book.mu.RLock()
	defer book.mu.RUnlock()

	return &OrderBook{
		Symbol: book.Symbol,
		Bids:   append([]*Order{}, book.Bids...),
		Asks:   append([]*Order{}, book.Asks...),
	}
}

func (m *Matcher) GetTrades() <-chan *Trade {
	return m.trades
}
