package engine

import (
	"sync"
	"time"
)

type OrderSide string

const (
	Buy  OrderSide = "BUY"
	Sell OrderSide = "SELL"
)

type OrderStatus string

const (
	Pending   OrderStatus = "PENDING"
	Filled    OrderStatus = "FILLED"
	PartialFilled OrderStatus = "PARTIAL_FILLED"
	Cancelled OrderStatus = "CANCELLED"
)

type Order struct {
	ID        string
	Symbol    string
	Side      OrderSide
	Price     float64
	Quantity  float64
	Filled    float64
	Status    OrderStatus
	Timestamp int64
	UserID    string
}

type Trade struct {
	ID        string
	Symbol    string
	BuyOrderID  string
	SellOrderID string
	Price     float64
	Quantity  float64
	Timestamp int64
}

type OrderBook struct {
	Symbol string
	Bids   []*Order // sorted by price descending, then timestamp ascending
	Asks   []*Order // sorted by price ascending, then timestamp ascending
	mu     sync.RWMutex
}

type Matcher struct {
	books  map[string]*OrderBook
	trades chan *Trade
	mu     sync.RWMutex
}
