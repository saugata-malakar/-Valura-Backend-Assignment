package engine

import (
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func TestConcurrentOrders(t *testing.T) {
	matcher := NewMatcher()
	numGoroutines := 100
	ordersPerGoroutine := 100

	var wg sync.WaitGroup
	var totalOrders int64

	for g := 0; g < numGoroutines; g++ {
		wg.Add(1)
		go func(goroutineID int) {
			defer wg.Done()
			for i := 0; i < ordersPerGoroutine; i++ {
				side := Buy
				if i%2 == 0 {
					side = Sell
				}
				_, err := matcher.PlaceOrder(
					"BTC/USD",
					side,
					50000+float64((goroutineID*i)%100),
					1.0,
					"user",
				)
				if err == nil {
					atomic.AddInt64(&totalOrders, 1)
				}
			}
		}(g)
	}

	wg.Wait()

	if totalOrders != int64(numGoroutines*ordersPerGoroutine) {
		t.Errorf("Total orders placed = %d, want %d", totalOrders, numGoroutines*ordersPerGoroutine)
	}
}

func TestThroughput(t *testing.T) {
	matcher := NewMatcher()
	numOrders := 10000

	start := time.Now()
	for i := 0; i < numOrders; i++ {
		side := Buy
		if i%2 == 0 {
			side = Sell
		}
		matcher.PlaceOrder("BTC/USD", side, 50000, 1.0, "user")
	}
	elapsed := time.Since(start)

	throughput := float64(numOrders) / elapsed.Seconds()
	t.Logf("Throughput: %.0f orders/sec", throughput)

	if throughput < 2000 {
		t.Errorf("Throughput = %.0f orders/sec, want >= 2000", throughput)
	}
}

func TestNoRaceConditions(t *testing.T) {
	matcher := NewMatcher()
	var wg sync.WaitGroup

	// Place orders from multiple goroutines
	for i := 0; i < 50; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			matcher.PlaceOrder("BTC/USD", Buy, 50000, 1.0, "user")
		}()
	}

	// Cancel orders concurrently
	book := matcher.GetOrderBook("BTC/USD")
	if book != nil {
		for _, bid := range book.Bids {
			wg.Add(1)
			go func(orderID string) {
				defer wg.Done()
				matcher.CancelOrder(orderID)
			}(bid.ID)
		}
	}

	wg.Wait()
}
