package engine

import (
	"testing"
)

func TestPlaceOrder_BuyOrderFullMatch(t *testing.T) {
	matcher := NewMatcher()
	
	// Place sell order
	sellOrder, err := matcher.PlaceOrder("BTC/USD", Sell, 50000, 1.0, "user1")
	if err != nil {
		t.Fatalf("Failed to place sell order: %v", err)
	}
	if sellOrder.Status != Filled {
		t.Errorf("Sell order status = %v, want %v", sellOrder.Status, Filled)
	}

	// Place matching buy order
	buyOrder, err := matcher.PlaceOrder("BTC/USD", Buy, 50000, 1.0, "user2")
	if err != nil {
		t.Fatalf("Failed to place buy order: %v", err)
	}
	if buyOrder.Status != Filled {
		t.Errorf("Buy order status = %v, want %v", buyOrder.Status, Filled)
	}
	if buyOrder.Filled != 1.0 {
		t.Errorf("Buy order filled = %v, want 1.0", buyOrder.Filled)
	}
}

func TestPlaceOrder_PartialFill(t *testing.T) {
	matcher := NewMatcher()

	// Place sell order for 0.5 BTC
	_, err := matcher.PlaceOrder("BTC/USD", Sell, 50000, 0.5, "user1")
	if err != nil {
		t.Fatalf("Failed to place sell order: %v", err)
	}

	// Place buy order for 1.0 BTC at same price
	buyOrder, err := matcher.PlaceOrder("BTC/USD", Buy, 50000, 1.0, "user2")
	if err != nil {
		t.Fatalf("Failed to place buy order: %v", err)
	}

	if buyOrder.Status != PartialFilled {
		t.Errorf("Buy order status = %v, want %v", buyOrder.Status, PartialFilled)
	}
	if buyOrder.Filled != 0.5 {
		t.Errorf("Buy order filled = %v, want 0.5", buyOrder.Filled)
	}

	// Check order book has remaining buy order
	book := matcher.GetOrderBook("BTC/USD")
	if len(book.Bids) != 1 {
		t.Errorf("Order book bids count = %d, want 1", len(book.Bids))
	}
}

func TestPlaceOrder_PriceMismatch(t *testing.T) {
	matcher := NewMatcher()

	// Place sell order at 50000
	_, err := matcher.PlaceOrder("BTC/USD", Sell, 50000, 1.0, "user1")
	if err != nil {
		t.Fatalf("Failed to place sell order: %v", err)
	}

	// Place buy order at lower price
	buyOrder, err := matcher.PlaceOrder("BTC/USD", Buy, 49999, 1.0, "user2")
	if err != nil {
		t.Fatalf("Failed to place buy order: %v", err)
	}

	if buyOrder.Status != Pending {
		t.Errorf("Buy order status = %v, want %v", buyOrder.Status, Pending)
	}
	if buyOrder.Filled != 0 {
		t.Errorf("Buy order filled = %v, want 0", buyOrder.Filled)
	}
}

func TestPlaceOrder_PriceTimePriority(t *testing.T) {
	matcher := NewMatcher()

	// Place two sell orders at same price
	sell1, _ := matcher.PlaceOrder("BTC/USD", Sell, 50000, 1.0, "user1")
	sell2, _ := matcher.PlaceOrder("BTC/USD", Sell, 50000, 1.0, "user2")

	// Place buy order that matches both
	buyOrder, _ := matcher.PlaceOrder("BTC/USD", Buy, 50000, 2.0, "user3")

	if buyOrder.Filled != 2.0 {
		t.Errorf("Buy order filled = %v, want 2.0", buyOrder.Filled)
	}

	// Verify first-in-first-out ordering
	if sell1.Filled != 1.0 || sell2.Filled != 1.0 {
		t.Errorf("Expected both sell orders to be fully filled")
	}
}

func TestCancelOrder(t *testing.T) {
	matcher := NewMatcher()

	order, _ := matcher.PlaceOrder("BTC/USD", Buy, 50000, 1.0, "user1")
	err := matcher.CancelOrder(order.ID)
	if err != nil {
		t.Fatalf("Failed to cancel order: %v", err)
	}

	book := matcher.GetOrderBook("BTC/USD")
	if len(book.Bids) != 0 {
		t.Errorf("Order book should be empty after cancellation")
	}
}

func TestGetOrderBook(t *testing.T) {
	matcher := NewMatcher()

	matcher.PlaceOrder("BTC/USD", Buy, 49999, 1.0, "user1")
	matcher.PlaceOrder("BTC/USD", Buy, 49998, 1.0, "user2")
	matcher.PlaceOrder("BTC/USD", Sell, 50001, 1.0, "user3")

	book := matcher.GetOrderBook("BTC/USD")
	if len(book.Bids) != 2 {
		t.Errorf("Order book bids count = %d, want 2", len(book.Bids))
	}
	if len(book.Asks) != 1 {
		t.Errorf("Order book asks count = %d, want 1", len(book.Asks))
	}

	// Verify bid ordering (highest price first)
	if book.Bids[0].Price != 49999 {
		t.Errorf("First bid price = %v, want 49999", book.Bids[0].Price)
	}
}
