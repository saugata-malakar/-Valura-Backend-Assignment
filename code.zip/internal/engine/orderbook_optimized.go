package engine

import (
	"math/rand"
)

// SkipListNode represents a node in the skiplist
type SkipListNode struct {
	Order    *Order
	Levels   []*SkipListNode
	Backward *SkipListNode
}

const MaxLevel = 16

type SkipList struct {
	Header *SkipListNode
	Level  int
}

func NewSkipList() *SkipList {
	header := &SkipListNode{
		Levels: make([]*SkipListNode, MaxLevel),
	}
	return &SkipList{Header: header, Level: 1}
}

func (sl *SkipList) Insert(order *Order, descending bool) {
	update := make([]*SkipListNode, MaxLevel)
	x := sl.Header

	// Find position
	for i := sl.Level - 1; i >= 0; i-- {
		for x.Levels[i] != nil {
			cmp := compareOrders(x.Levels[i].Order, order, descending)
			if cmp < 0 {
				break
			}
			x = x.Levels[i]
		}
		update[i] = x
	}

	// Insert
	lvl := randomLevel()
	if lvl > sl.Level {
		for i := sl.Level; i < lvl; i++ {
			update[i] = sl.Header
		}
		sl.Level = lvl
	}

	newNode := &SkipListNode{
		Order:  order,
		Levels: make([]*SkipListNode, lvl),
	}

	for i := 0; i < lvl; i++ {
		newNode.Levels[i] = update[i].Levels[i]
		update[i].Levels[i] = newNode
	}
}

func compareOrders(o1, o2 *Order, descending bool) int {
	if o1.Price != o2.Price {
		if descending {
			return -1 * compare(o1.Price, o2.Price)
		}
		return compare(o1.Price, o2.Price)
	}
	if o1.Timestamp < o2.Timestamp {
		return -1
	}
	if o1.Timestamp > o2.Timestamp {
		return 1
	}
	return 0
}

func compare(a, b float64) int {
	if a < b {
		return -1
	}
	if a > b {
		return 1
	}
	return 0
}

func randomLevel() int {
	lvl := 1
	for randomBool() && lvl < MaxLevel {
		lvl++
	}
	return lvl
}

func randomBool() bool {
	return rand.Intn(2) == 1
}
