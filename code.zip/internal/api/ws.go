package api

import (
	"encoding/json"
	"log"
	"net/http"
	"sync"

	"github.com/gorilla/websocket"
	"exchange-backend/internal/engine"
	"exchange-backend/internal/persistence"
)

type WebSocketHandler struct {
	matcher   *engine.Matcher
	tradeRepo *persistence.TradeRepository
	clients   map[*Client]bool
	broadcast chan interface{}
	register  chan *Client
	unregister chan *Client
	mu        sync.RWMutex
}

type Client struct {
	conn      *websocket.Conn
	send      chan interface{}
	symbol    string
}

type WSMessage struct {
	Type    string      `json:"type"`
	Symbol  string      `json:"symbol"`
	Payload interface{} `json:"payload"`
}

var upgrader = websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool {
		return true // Allow all origins for testing
	},
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
}

func NewWebSocketHandler(matcher *engine.Matcher, tradeRepo *persistence.TradeRepository) *WebSocketHandler {
	wsh := &WebSocketHandler{
		matcher:    matcher,
		tradeRepo:  tradeRepo,
		clients:    make(map[*Client]bool),
		broadcast: make(chan interface{}, 10000),
		register:  make(chan *Client),
		unregister: make(chan *Client),
	}

	// Start broadcast loop
	go wsh.broadcastLoop()

	// Start trade listener
	go wsh.listenTrades()

	return wsh
}

func (wsh *WebSocketHandler) Handle(w http.ResponseWriter, r *http.Request) {
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Printf("WebSocket upgrade failed: %v", err)
		return
	}

	client := &Client{
		conn: conn,
		send: make(chan interface{}, 256),
	}

	wsh.register <- client

	go wsh.clientReadLoop(client)
	go wsh.clientWriteLoop(client)
}

func (wsh *WebSocketHandler) clientReadLoop(client *Client) {
	defer func() {
		wsh.unregister <- client
		client.conn.Close()
	}()

	for {
		var msg WSMessage
		err := client.conn.ReadJSON(&msg)
		if err != nil {
			if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure) {
				log.Printf("WebSocket error: %v", err)
			}
			return
		}

		if msg.Type == "subscribe" {
			client.symbol = msg.Symbol
			// Send initial order book
			book := wsh.matcher.GetOrderBook(msg.Symbol)
			if book != nil {
				client.send <- WSMessage{
					Type:   "orderbook",
					Symbol: msg.Symbol,
					Payload: map[string]interface{}{
						"bids": book.Bids,
						"asks": book.Asks,
					},
				}
			}
		}
	}
}

func (wsh *WebSocketHandler) clientWriteLoop(client *Client) {
	defer client.conn.Close()

	for msg := range client.send {
		if wsMsg, ok := msg.(WSMessage); ok && wsMsg.Symbol != client.symbol {
			continue // Skip messages not for this symbol
		}
		if err := client.conn.WriteJSON(msg); err != nil {
			return
		}
	}
}

func (wsh *WebSocketHandler) listenTrades() {
	trades := wsh.matcher.GetTrades()
	for trade := range trades {
		wsh.broadcast <- WSMessage{
			Type:   "trade",
			Symbol: trade.Symbol,
			Payload: TradeResponse{
				ID:          trade.ID,
				Symbol:      trade.Symbol,
				BuyOrderID:  trade.BuyOrderID,
				SellOrderID: trade.SellOrderID,
				Price:       trade.Price,
				Quantity:    trade.Quantity,
				Timestamp:   trade.Timestamp,
			},
		}
	}
}

func (wsh *WebSocketHandler) broadcastLoop() {
	for {
		select {
		case client := <-wsh.register:
			wsh.mu.Lock()
			wsh.clients[client] = true
			wsh.mu.Unlock()
			log.Printf("Client registered, total: %d", len(wsh.clients))

		case client := <-wsh.unregister:
			wsh.mu.Lock()
			if _, ok := wsh.clients[client]; ok {
				delete(wsh.clients, client)
				close(client.send)
			}
			wsh.mu.Unlock()
			log.Printf("Client unregistered, total: %d", len(wsh.clients))

		case msg := <-wsh.broadcast:
			wsh.mu.RLock()
			for client := range wsh.clients {
				select {
				case client.send <- msg:
				default:
					// Skip slow clients
				}
			}
			wsh.mu.RUnlock()
		}
	}
}

type OrderBookDelta struct {
	BidsChanged []OrderLevel `json:"bids_changed"`
	AsksChanged []OrderLevel `json:"asks_changed"`
}
