package api

import (
	"database/sql"
	"encoding/json"
	"net/http"

	"exchange-backend/internal/engine"
	"exchange-backend/internal/persistence"
)

type Handler struct {
	db      *sql.DB
	matcher *engine.Matcher
	orderRepo *persistence.OrderRepository
	tradeRepo *persistence.TradeRepository
}

func NewHandler(db *sql.DB, matcher *engine.Matcher) *Handler {
	return &Handler{
		db: db,
		matcher: matcher,
		orderRepo: persistence.NewOrderRepository(db),
		tradeRepo: persistence.NewTradeRepository(db),
	}
}

func (h *Handler) Router() http.Handler {
	mux := http.NewServeMux()
	
	mux.HandleFunc("POST /orders", h.handlePlaceOrder)
	mux.HandleFunc("DELETE /orders/{id}", h.handleCancelOrder)
	mux.HandleFunc("GET /orders/{id}", h.handleGetOrder)
	mux.HandleFunc("GET /orders", h.handleGetUserOrders)
	mux.HandleFunc("GET /books/{symbol}", h.handleGetOrderBook)
	mux.HandleFunc("GET /trades/{symbol}", h.handleGetTrades)
	
	mux.HandleFunc("GET /ws", h.handleWebSocket)
	mux.HandleFunc("GET /health", h.handleHealth)
	
	return mux
}

type PlaceOrderRequest struct {
	Symbol   string  `json:"symbol"`
	Side     string  `json:"side"`
	Price    float64 `json:"price"`
	Quantity float64 `json:"quantity"`
	UserID   string  `json:"user_id"`
	ClientID string  `json:"client_id"` // for idempotency
}

type OrderResponse struct {
	ID       string  `json:"id"`
	Symbol   string  `json:"symbol"`
	Side     string  `json:"side"`
	Price    float64 `json:"price"`
	Quantity float64 `json:"quantity"`
	Filled   float64 `json:"filled"`
	Status   string  `json:"status"`
}

func (h *Handler) handlePlaceOrder(w http.ResponseWriter, r *http.Request) {
	var req PlaceOrderRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}

	if req.Symbol == "" || req.UserID == "" || req.Quantity <= 0 || req.Price < 0 {
		http.Error(w, "Missing or invalid fields", http.StatusBadRequest)
		return
	}

	order, err := h.matcher.PlaceOrder(
		req.Symbol,
		engine.OrderSide(req.Side),
		req.Price,
		req.Quantity,
		req.UserID,
	)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Persist order
	if err := h.orderRepo.Save(r.Context(), order); err != nil {
		http.Error(w, "Failed to persist order", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(OrderResponse{
		ID:       order.ID,
		Symbol:   order.Symbol,
		Side:     string(order.Side),
		Price:    order.Price,
		Quantity: order.Quantity,
		Filled:   order.Filled,
		Status:   string(order.Status),
	})
}

func (h *Handler) handleCancelOrder(w http.ResponseWriter, r *http.Request) {
	orderID := r.PathValue("id")
	if orderID == "" {
		http.Error(w, "Order ID required", http.StatusBadRequest)
		return
	}

	if err := h.matcher.CancelOrder(orderID); err != nil {
		http.Error(w, err.Error(), http.StatusNotFound)
		return
	}

	w.WriteHeader(http.StatusOK)
}

func (h *Handler) handleGetOrder(w http.ResponseWriter, r *http.Request) {
	orderID := r.PathValue("id")
	order, err := h.orderRepo.FindByID(r.Context(), orderID)
	if err != nil {
		http.Error(w, "Failed to retrieve order", http.StatusInternalServerError)
		return
	}
	if order == nil {
		http.Error(w, "Order not found", http.StatusNotFound)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(OrderResponse{
		ID:       order.ID,
		Symbol:   order.Symbol,
		Side:     string(order.Side),
		Price:    order.Price,
		Quantity: order.Quantity,
		Filled:   order.Filled,
		Status:   string(order.Status),
	})
}

type GetOrdersQuery struct {
	Limit  int
	Offset int
}

func (h *Handler) handleGetUserOrders(w http.ResponseWriter, r *http.Request) {
	userID := r.URL.Query().Get("user_id")
	if userID == "" {
		http.Error(w, "user_id required", http.StatusBadRequest)
		return
	}

	limit := 50
	offset := 0
	if l := r.URL.Query().Get("limit"); l != "" {
		if _, err := json.Unmarshal([]byte(l), &limit); err == nil && limit > 0 && limit <= 100 {
			// limit validated
		}
	}

	orders, err := h.orderRepo.FindByUserID(r.Context(), userID, limit, offset)
	if err != nil {
		http.Error(w, "Failed to retrieve orders", http.StatusInternalServerError)
		return
	}

	responses := make([]OrderResponse, len(orders))
	for i, order := range orders {
		responses[i] = OrderResponse{
			ID:       order.ID,
			Symbol:   order.Symbol,
			Side:     string(order.Side),
			Price:    order.Price,
			Quantity: order.Quantity,
			Filled:   order.Filled,
			Status:   string(order.Status),
		}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(responses)
}

type OrderBookResponse struct {
	Symbol string         `json:"symbol"`
	Bids   []OrderLevel   `json:"bids"`
	Asks   []OrderLevel   `json:"asks"`
}

type OrderLevel struct {
	Price    float64 `json:"price"`
	Quantity float64 `json:"quantity"`
	Count    int     `json:"count"`
}

func (h *Handler) handleGetOrderBook(w http.ResponseWriter, r *http.Request) {
	symbol := r.PathValue("symbol")
	if symbol == "" {
		http.Error(w, "Symbol required", http.StatusBadRequest)
		return
	}

	book := h.matcher.GetOrderBook(symbol)
	if book == nil {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(OrderBookResponse{Symbol: symbol})
		return
	}

	// Aggregate by price level
	bidLevels := aggregateOrderLevels(book.Bids)
	askLevels := aggregateOrderLevels(book.Asks)

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(OrderBookResponse{
		Symbol: symbol,
		Bids:   bidLevels,
		Asks:   askLevels,
	})
}

func aggregateOrderLevels(orders []*engine.Order) []OrderLevel {
	priceMap := make(map[float64]*OrderLevel)
	for _, order := range orders {
		if level, exists := priceMap[order.Price]; exists {
			level.Quantity += order.Quantity - order.Filled
			level.Count++
		} else {
			priceMap[order.Price] = &OrderLevel{
				Price:    order.Price,
				Quantity: order.Quantity - order.Filled,
				Count:    1,
			}
		}
	}

	levels := make([]OrderLevel, 0, len(priceMap))
	for _, level := range priceMap {
		levels = append(levels, *level)
	}
	return levels
}

type TradeResponse struct {
	ID          string  `json:"id"`
	Symbol      string  `json:"symbol"`
	BuyOrderID  string  `json:"buy_order_id"`
	SellOrderID string  `json:"sell_order_id"`
	Price       float64 `json:"price"`
	Quantity    float64 `json:"quantity"`
	Timestamp   int64   `json:"timestamp"`
}

func (h *Handler) handleGetTrades(w http.ResponseWriter, r *http.Request) {
	symbol := r.PathValue("symbol")
	if symbol == "" {
		http.Error(w, "Symbol required", http.StatusBadRequest)
		return
	}

	trades, err := h.tradeRepo.FindBySymbol(r.Context(), symbol, 100, 0)
	if err != nil {
		http.Error(w, "Failed to retrieve trades", http.StatusInternalServerError)
		return
	}

	responses := make([]TradeResponse, len(trades))
	for i, trade := range trades {
		responses[i] = TradeResponse{
			ID:          trade.ID,
			Symbol:      trade.Symbol,
			BuyOrderID:  trade.BuyOrderID,
			SellOrderID: trade.SellOrderID,
			Price:       trade.Price,
			Quantity:    trade.Quantity,
			Timestamp:   trade.Timestamp,
		}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(responses)
}

func (h *Handler) handleHealth(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"status": "healthy"})
}

func (h *Handler) handleWebSocket(w http.ResponseWriter, r *http.Request) {
	ws := NewWebSocketHandler(h.matcher, h.tradeRepo)
	ws.Handle(w, r)
}
