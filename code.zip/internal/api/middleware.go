package api

import (
	"context"
	"net/http"
	"strings"
	"time"
)

func LoggingMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		next.ServeHTTP(w, r)
		duration := time.Since(start)
		log.Printf("%s %s %s", r.Method, r.RequestURI, duration)
	})
}

type RateLimiter struct {
	requestCounts map[string]int
	lastReset     time.Time
	maxRequests   int
	windowSize    time.Duration
}

func NewRateLimiter(maxRequests int, windowSize time.Duration) *RateLimiter {
	rl := &RateLimiter{
		requestCounts: make(map[string]int),
		lastReset:     time.Now(),
		maxRequests:   maxRequests,
		windowSize:    windowSize,
	}

	go func() {
		ticker := time.NewTicker(windowSize)
		for range ticker.C {
			rl.requestCounts = make(map[string]int)
			rl.lastReset = time.Now()
		}
	}()

	return rl
}

func (rl *RateLimiter) Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		clientIP := getClientIP(r)
		if rl.requestCounts[clientIP] >= rl.maxRequests {
			http.Error(w, "Rate limit exceeded", http.StatusTooManyRequests)
			return
		}
		rl.requestCounts[clientIP]++
		next.ServeHTTP(w, r)
	})
}

func getClientIP(r *http.Request) string {
	if forwarded := r.Header.Get("X-Forwarded-For"); forwarded != "" {
		return strings.Split(forwarded, ",")[0]
	}
	return strings.Split(r.RemoteAddr, ":")[0]
}

func TimeoutMiddleware(timeout time.Duration) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			ctx, cancel := context.WithTimeout(r.Context(), timeout)
			defer cancel()
			next.ServeHTTP(w, r.WithContext(ctx))
		})
	}
}

var log = func(args ...interface{}) {
	// placeholder
}
