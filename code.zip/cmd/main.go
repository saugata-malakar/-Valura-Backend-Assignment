package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"exchange-backend/internal/api"
	"exchange-backend/internal/engine"
	"exchange-backend/internal/persistence"
	"exchange-backend/internal/metrics"
)

func main() {
	// Initialize database
	db, err := persistence.NewDB(os.Getenv("DATABASE_URL"))
	if err != nil {
		log.Fatalf("Failed to initialize database: %v", err)
	}
	defer db.Close()

	// Run migrations
	if err := persistence.RunMigrations(db); err != nil {
		log.Fatalf("Failed to run migrations: %v", err)
	}

	// Initialize metrics
	metrics.Init()

	// Initialize matching engine
	matcher := engine.NewMatcher()

	// Initialize API handler
	handler := api.NewHandler(db, matcher)

	// Start HTTP server
	httpServer := &http.Server{
		Addr:         fmt.Sprintf(":%s", os.Getenv("HTTP_PORT")),
		Handler:      handler.Router(),
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
	}

	// Start metrics server
	metricsServer := &http.Server{
		Addr:    fmt.Sprintf(":%s", os.Getenv("METRICS_PORT")),
		Handler: metrics.Handler(),
	}

	go func() {
		log.Printf("Starting HTTP server on %s", httpServer.Addr)
		if err := httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("HTTP server error: %v", err)
		}
	}()

	go func() {
		log.Printf("Starting metrics server on %s", metricsServer.Addr)
		if err := metricsServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Metrics server error: %v", err)
		}
	}()

	// Graceful shutdown
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	<-sigChan

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	httpServer.Shutdown(ctx)
	metricsServer.Shutdown(ctx)
	log.Println("Server shut down gracefully")
}
