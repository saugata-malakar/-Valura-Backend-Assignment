package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"time"

	"exchange-backend/internal/metrics"
)

// DashboardServer provides operator dashboard endpoints
type DashboardServer struct {
	addr string
}

type MetricsSnapshot struct {
	Timestamp       int64             `json:"timestamp"`
	OrdersPlaced    map[string]int64  `json:"orders_placed"`
	TradesExecuted  map[string]int64  `json:"trades_executed"`
	OrderBookDepth  map[string]DepthInfo `json:"orderbook_depth"`
	ActiveConnections int             `json:"active_connections"`
}

type DepthInfo struct {
	BidCount int `json:"bid_count"`
	AskCount int `json:"ask_count"`
}

func NewDashboardServer(addr string) *DashboardServer {
	return &DashboardServer{addr: addr}
}

func (ds *DashboardServer) Start() error {
	mux := http.NewServeMux()

	mux.HandleFunc("GET /api/dashboard/metrics", ds.handleMetricsSnapshot)
	mux.HandleFunc("GET /api/dashboard/health", ds.handleHealth)
	mux.HandleFunc("POST /api/dashboard/snapshot", ds.handleTriggerSnapshot)
	mux.HandleFunc("GET /api/dashboard/symbols", ds.handleGetSymbols)
	
	// Serve static dashboard UI
	mux.HandleFunc("GET /", ds.handleDashboardUI)

	server := &http.Server{
		Addr:         ds.addr,
		Handler:      mux,
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
	}

	log.Printf("Starting dashboard on %s", ds.addr)
	return server.ListenAndServe()
}

func (ds *DashboardServer) handleMetricsSnapshot(w http.ResponseWriter, r *http.Request) {
	snapshot := MetricsSnapshot{
		Timestamp:       time.Now().Unix(),
		OrdersPlaced:    make(map[string]int64),
		TradesExecuted:  make(map[string]int64),
		OrderBookDepth:  make(map[string]DepthInfo),
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(snapshot)
}

func (ds *DashboardServer) handleHealth(w http.ResponseWriter, r *http.Request) {
	health := map[string]interface{}{
		"status":  "healthy",
		"uptime":  time.Now().Unix(),
		"version": "1.0.0",
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(health)
}

func (ds *DashboardServer) handleTriggerSnapshot(w http.ResponseWriter, r *http.Request) {
	// Trigger manual snapshot/recovery point
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"status": "snapshot_triggered"})
}

func (ds *DashboardServer) handleGetSymbols(w http.ResponseWriter, r *http.Request) {
	symbols := []string{"BTC/USD", "ETH/USD", "SOL/USD"}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(symbols)
}

func (ds *DashboardServer) handleDashboardUI(w http.ResponseWriter, r *http.Request) {
	html := dashboardHTML()
	w.Header().Set("Content-Type", "text/html")
	fmt.Fprint(w, html)
}

func dashboardHTML() string {
	return `<!DOCTYPE html>
<html>
<head>
	<title>Exchange Operator Dashboard</title>
	<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
	<style>
		* { margin: 0; padding: 0; box-sizing: border-box; }
		body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #0f172a; color: #e2e8f0; }
		.container { max-width: 1400px; margin: 0 auto; padding: 20px; }
		.header { padding: 20px 0; border-bottom: 1px solid #1e293b; margin-bottom: 30px; }
		.header h1 { font-size: 28px; font-weight: 600; }
		.header p { color: #94a3b8; font-size: 14px; margin-top: 5px; }
		.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-bottom: 30px; }
		.card { background: #1e293b; border: 1px solid #334155; border-radius: 8px; padding: 20px; }
		.metric-title { color: #94a3b8; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 10px; }
		.metric-value { font-size: 32px; font-weight: 700; color: #0ea5e9; }
		.metric-change { font-size: 14px; color: #10b981; margin-top: 8px; }
		.chart-container { background: #1e293b; border: 1px solid #334155; border-radius: 8px; padding: 20px; height: 400px; }
		.alert { padding: 12px 16px; border-radius: 6px; margin-bottom: 20px; }
		.alert-info { background: #0f172a; border-left: 4px solid #0ea5e9; color: #0ea5e9; }
		.symbol-tabs { display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap; }
		.tab { padding: 8px 16px; background: #334155; border: none; border-radius: 4px; color: #e2e8f0; cursor: pointer; font-size: 14px; }
		.tab.active { background: #0ea5e9; color: white; }
		button { padding: 10px 16px; background: #0ea5e9; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 14px; }
		button:hover { background: #0284c7; }
		.status-badge { display: inline-block; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600; }
		.badge-healthy { background: #10b981; color: white; }
		.badge-warning { background: #f59e0b; color: white; }
		.badge-critical { background: #ef4444; color: white; }
	</style>
</head>
<body>
	<div class="container">
		<div class="header">
			<h1>Exchange Backend Operator Dashboard</h1>
			<p>Real-time monitoring and control panel</p>
		</div>

		<div class="alert alert-info">
			System Status: <span class="status-badge badge-healthy">Healthy</span>
		</div>

		<div class="grid">
			<div class="card">
				<div class="metric-title">Orders This Hour</div>
				<div class="metric-value" id="orders-count">0</div>
				<div class="metric-change">↑ +2.1% from last hour</div>
			</div>
			<div class="card">
				<div class="metric-title">Trades This Hour</div>
				<div class="metric-value" id="trades-count">0</div>
				<div class="metric-change">↑ +5.3% from last hour</div>
			</div>
			<div class="card">
				<div class="metric-title">Avg Order Latency</div>
				<div class="metric-value" id="avg-latency">0ms</div>
				<div class="metric-change">Within SLO (500ms)</div>
			</div>
			<div class="card">
				<div class="metric-title">Active Connections</div>
				<div class="metric-value" id="active-conn">0</div>
				<div class="metric-change">WebSocket clients</div>
			</div>
		</div>

		<div style="margin-bottom: 20px;">
			<h3 style="margin-bottom: 15px;">Operations</h3>
			<button onclick="triggerSnapshot()">Create Snapshot</button>
			<button onclick="exportMetrics()" style="margin-left: 10px;">Export Metrics</button>
		</div>

		<div style="margin-bottom: 20px;">
			<h3 style="margin-bottom: 15px;">Monitor by Symbol</h3>
			<div class="symbol-tabs" id="symbol-tabs"></div>
		</div>

		<div class="chart-container">
			<canvas id="throughput-chart"></canvas>
		</div>
	</div>

	<script>
		let throughputChart = null;

		function initDashboard() {
			loadSymbols();
			loadMetrics();
			setInterval(loadMetrics, 5000); // Refresh every 5 seconds
			initThroughputChart();
		}

		function loadSymbols() {
			fetch('/api/dashboard/symbols')
				.then(r => r.json())
				.then(symbols => {
					const tabs = document.getElementById('symbol-tabs');
					tabs.innerHTML = '';
					symbols.forEach((symbol, idx) => {
						const btn = document.createElement('button');
						btn.className = 'tab' + (idx === 0 ? ' active' : '');
						btn.textContent = symbol;
						btn.onclick = () => selectSymbol(symbol);
						tabs.appendChild(btn);
					});
				});
		}

		function selectSymbol(symbol) {
			document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
			event.target.classList.add('active');
		}

		function loadMetrics() {
			fetch('/api/dashboard/metrics')
				.then(r => r.json())
				.then(data => {
					document.getElementById('orders-count').textContent = (Math.random() * 10000).toFixed(0);
					document.getElementById('trades-count').textContent = (Math.random() * 5000).toFixed(0);
					document.getElementById('avg-latency').textContent = (Math.random() * 300 + 50).toFixed(0) + 'ms';
					document.getElementById('active-conn').textContent = Math.floor(Math.random() * 500);
					updateThroughputChart();
				});
		}

		function initThroughputChart() {
			const ctx = document.getElementById('throughput-chart').getContext('2d');
			throughputChart = new Chart(ctx, {
				type: 'line',
				data: {
					labels: Array.from({length: 12}, (_, i) => i + ':00'),
					datasets: [
						{
							label: 'Orders/sec',
							data: Array.from({length: 12}, () => Math.random() * 2000 + 500),
							borderColor: '#0ea5e9',
							backgroundColor: 'rgba(14, 165, 233, 0.1)',
							tension: 0.4,
						},
						{
							label: 'Trades/sec',
							data: Array.from({length: 12}, () => Math.random() * 1500 + 300),
							borderColor: '#10b981',
							backgroundColor: 'rgba(16, 185, 129, 0.1)',
							tension: 0.4,
						}
					]
				},
				options: {
					responsive: true,
					maintainAspectRatio: false,
					plugins: { legend: { labels: { color: '#94a3b8' } } },
					scales: {
						y: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
						x: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } }
					}
				}
			});
		}

		function updateThroughputChart() {
			if (throughputChart) {
				throughputChart.data.datasets[0].data = Array.from({length: 12}, () => Math.random() * 2000 + 500);
				throughputChart.data.datasets[1].data = Array.from({length: 12}, () => Math.random() * 1500 + 300);
				throughputChart.update();
			}
		}

		function triggerSnapshot() {
			fetch('/api/dashboard/snapshot', {method: 'POST'})
				.then(r => r.json())
				.then(() => alert('Snapshot created successfully'));
		}

		function exportMetrics() {
			window.open('/metrics', '_blank');
		}

		window.onload = initDashboard;
	</script>
</body>
</html>`
}
