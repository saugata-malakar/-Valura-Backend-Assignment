#!/bin/bash

set -e

echo "Starting load tests..."

# Check if server is running
if ! nc -z localhost 8080; then
    echo "Error: Server not running on port 8080"
    exit 1
fi

echo ""
echo "=== Running K6 Basic Load Test ==="
if command -v k6 &> /dev/null; then
    k6 run load-tests/k6-basic.js
else
    echo "K6 not installed. Install with: npm install -g k6"
fi

echo ""
echo "=== Running K6 Spike Test ==="
if command -v k6 &> /dev/null; then
    k6 run load-tests/k6-spike.js
else
    echo "K6 not installed"
fi

echo ""
echo "=== Running Vegeta Load Test ==="
if command -v vegeta &> /dev/null; then
    cd load-tests
    go run vegeta-load.go -duration 30s -rate 2000
    cd ..
else
    echo "Vegeta not installed. Install with: go get -u github.com/tsenart/vegeta/v12/cmd/vegeta"
fi

echo ""
echo "Load tests completed!"
