import http from "k6/http"
import { check, sleep, __VU, __ITER } from "k6"

export const options = {
  stages: [
    { duration: "1m", target: 100 }, // Ramp up to 100 users
    { duration: "3m", target: 500 }, // Ramp up to 500 users
    { duration: "5m", target: 1000 }, // Ramp up to 1000 users
    { duration: "2m", target: 1000 }, // Stay at 1000 users
    { duration: "1m", target: 0 }, // Ramp down
  ],
  thresholds: {
    http_req_duration: ["p(95)<500", "p(99)<1000"], // 95th percentile < 500ms, 99th < 1000ms
    http_req_failed: ["rate<0.1"], // Error rate < 10%
  },
}

const BASE_URL = "http://localhost:8080"
const symbols = ["BTC/USD", "ETH/USD", "SOL/USD"]

export default function () {
  const symbol = symbols[Math.floor(Math.random() * symbols.length)]
  const side = Math.random() > 0.5 ? "BUY" : "SELL"
  const price = 50000 + Math.random() * 1000
  const quantity = 0.1 + Math.random() * 10
  const userID = `user-${__VU}-${__ITER}`

  // Place order
  const placeOrderRes = http.post(
    `${BASE_URL}/orders`,
    JSON.stringify({
      symbol,
      side,
      price,
      quantity,
      user_id: userID,
      client_id: `${userID}-order-1`,
    }),
    {
      headers: { "Content-Type": "application/json" },
    },
  )

  check(placeOrderRes, {
    "place order status 201": (r) => r.status === 201,
    "place order has order id": (r) => {
      try {
        const body = JSON.parse(r.body)
        return body.id && body.id.length > 0
      } catch {
        return false
      }
    },
  })

  sleep(0.1)

  // Get order book
  const bookRes = http.get(`${BASE_URL}/books/${symbol}`)
  check(bookRes, {
    "get book status 200": (r) => r.status === 200,
    "book has bids or asks": (r) => {
      try {
        const body = JSON.parse(r.body)
        return (body.bids && body.bids.length > 0) || (body.asks && body.asks.length > 0)
      } catch {
        return false
      }
    },
  })

  sleep(0.1)

  // Get trades
  const tradesRes = http.get(`${BASE_URL}/trades/${symbol}`)
  check(tradesRes, {
    "get trades status 200": (r) => r.status === 200,
  })

  sleep(0.5)
}
