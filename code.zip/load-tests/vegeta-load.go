package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"math/rand"
	"net/http"
	"strings"
	"time"

	"github.com/tsenart/vegeta/v12/lib"
)

func main() {
	duration := flag.Duration("duration", 30*time.Second, "Load test duration")
	rate := flag.Int("rate", 2000, "Requests per second")
	flag.Parse()

	baseURL := "http://localhost:8080"
	symbols := []string{"BTC/USD", "ETH/USD", "SOL/USD"}

	targeter := func(r *rand.Rand) *http.Request {
		symbol := symbols[r.Intn(len(symbols))]
		side := "BUY"
		if r.Float64() > 0.5 {
			side = "SELL"
		}

		payload := map[string]interface{}{
			"symbol":   symbol,
			"side":     side,
			"price":    50000 + r.Float64()*1000,
			"quantity": 0.1 + r.Float64()*10,
			"user_id":  fmt.Sprintf("vegeta-user-%d", r.Intn(10000)),
		}
		body, _ := json.Marshal(payload)

		req, _ := http.NewRequest("POST", baseURL+"/orders", strings.NewReader(string(body)))
		req.Header.Set("Content-Type", "application/json")
		return req
	}

	attacker := lib.NewAttacker()
	pacer := lib.ConstantPacer{Freq: *rate, Per: time.Second}

	results := attacker.Attack(
		lib.NewTargeter(targeter),
		pacer,
		*duration,
		"Load Test",
	)

	var successCount, failureCount int64
	var totalLatency time.Duration
	var latencies []time.Duration
	var maxLatency time.Duration

	for result := range results {
		if result.Error != "" {
			failureCount++
		} else {
			successCount++
			totalLatency += result.Latency
			latencies = append(latencies, result.Latency)
			if result.Latency > maxLatency {
				maxLatency = result.Latency
			}
		}
	}

	total := successCount + failureCount
	errorRate := float64(failureCount) / float64(total) * 100

	avgLatency := time.Duration(0)
	if successCount > 0 {
		avgLatency = totalLatency / time.Duration(successCount)
	}

	p95, p99 := calculatePercentiles(latencies)

	fmt.Printf("\n=== Load Test Results ===\n")
	fmt.Printf("Total Requests: %d\n", total)
	fmt.Printf("Successful: %d\n", successCount)
	fmt.Printf("Failed: %d\n", failureCount)
	fmt.Printf("Error Rate: %.2f%%\n", errorRate)
	fmt.Printf("Average Latency: %v\n", avgLatency)
	fmt.Printf("P95 Latency: %v\n", p95)
	fmt.Printf("P99 Latency: %v\n", p99)
	fmt.Printf("Max Latency: %v\n", maxLatency)
	fmt.Printf("Throughput: %.2f req/sec\n", float64(total)/*duration.Seconds())
}

func calculatePercentiles(latencies []time.Duration) (p95, p99 time.Duration) {
	if len(latencies) == 0 {
		return 0, 0
	}

	// Simple percentile calculation
	p95idx := len(latencies) * 95 / 100
	p99idx := len(latencies) * 99 / 100

	if p95idx < len(latencies) {
		p95 = latencies[p95idx]
	}
	if p99idx < len(latencies) {
		p99 = latencies[p99idx]
	}
	return
}
