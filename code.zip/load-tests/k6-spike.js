import http from "k6/http"
import { check, __VU } from "k6"

export const options = {
  stages: [
    { duration: "30s", target: 100 },
    { duration: "30s", target: 2000 }, // Spike to 2000 users
    { duration: "30s", target: 2000 }, // Maintain spike
    { duration: "30s", target: 0 }, // Quick drop
  ],
  thresholds: {
    http_req_duration: ["p(99)<2000"],
  },
}

const BASE_URL = "http://localhost:8080"

export default function () {
  const symbol = "BTC/USD"
  const side = Math.random() > 0.5 ? "BUY" : "SELL"

  const res = http.post(
    `${BASE_URL}/orders`,
    JSON.stringify({
      symbol,
      side,
      price: 50000 + Math.random() * 500,
      quantity: 0.5 + Math.random() * 5,
      user_id: `spike-user-${__VU}`,
    }),
    {
      headers: { "Content-Type": "application/json" },
    },
  )

  check(res, {
    "spike test status 201": (r) => r.status === 201,
    "spike test duration": (r) => r.timings.duration < 1000,
  })
}
