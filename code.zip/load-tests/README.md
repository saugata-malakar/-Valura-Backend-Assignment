# Load Testing Suite for Exchange Backend

This directory contains comprehensive load testing scripts for the cryptocurrency exchange backend.

## Prerequisites

### K6 (HTTP Load Testing)
\`\`\`bash
# macOS
brew install k6

# Linux
sudo apt-get install k6

# or via npm
npm install -g k6
\`\`\`

### Vegeta (HTTP Load Testing)
\`\`\`bash
go install github.com/tsenart/vegeta/v12/cmd/vegeta@latest
\`\`\`

## Running Tests

### Basic Load Test (K6)
Gradually ramps up from 100 to 1000 concurrent users:

\`\`\`bash
k6 run load-tests/k6-basic.js
\`\`\`

Metrics tracked:
- 95th percentile latency < 500ms
- 99th percentile latency < 1000ms
- Error rate < 10%

### Spike Test (K6)
Tests system behavior under sudden traffic spikes:

\`\`\`bash
k6 run load-tests/k6-spike.js
\`\`\`

Ramps to 2000 concurrent users in 30 seconds.

### Vegeta Load Test
Direct throughput test targeting 2000 orders/sec:

\`\`\`bash
cd load-tests
go run vegeta-load.go -duration 30s -rate 2000
cd ..
\`\`\`

### Run All Tests
\`\`\`bash
bash load-tests/run-load-tests.sh
\`\`\`

## Test Scenarios

### 1. Sustained Load (k6-basic.js)
- Tests system under sustained high load
- Ramp-up phase: 11 minutes total
- Peak load: 1000 concurrent users
- Validates latency SLOs

### 2. Spike Test (k6-spike.js)
- Tests system resilience to sudden traffic spikes
- 2000 concurrent users in 30 seconds
- Validates error handling and recovery

### 3. Raw Throughput (vegeta-load.go)
- Direct throughput measurement
- Target: 2000+ orders/sec
- Minimal overhead measurement

## Performance Targets

- **Throughput**: 2000+ orders/sec
- **P95 Latency**: < 500ms
- **P99 Latency**: < 1000ms
- **Error Rate**: < 0.1%
- **Maximum Latency**: < 2000ms

## Monitoring During Tests

In another terminal, monitor metrics:

\`\`\`bash
# Watch Prometheus metrics
curl http://localhost:9090/metrics | grep exchange

# Watch server logs
docker-compose logs -f exchange
\`\`\`

## Interpreting Results

### Success Criteria
- P95 latency consistently under 500ms
- Error rate below 0.1%
- Throughput sustains 2000+ req/sec

### Common Issues

**High Latency**
- Check database connection pooling
- Monitor CPU/memory usage
- Verify order matching algorithm efficiency

**High Error Rate**
- Check server logs for panic/errors
- Verify database is healthy
- Check order validation logic

**Throughput Below Target**
- May indicate bottleneck in matching engine
- Check thread pool/goroutine count
- Consider skiplist optimization for order books
